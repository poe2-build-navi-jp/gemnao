using System;
using System.Linq;

namespace Gemnao.Diagnostics
{
    public enum CaptureMode { InitialAttempt, InitialRecent, Retest, Refresh }
    public enum CaptureOrigin { Unknown, TimedAttempt, RecentWindow }

    // Create the whole transition before the UI replaces accepted results. No I/O or polling.
    public sealed class CaptureTransition
    {
        public Snapshot Current;
        public Snapshot Baseline;
        public TrialOutcome Outcome;
        public bool PreserveStepRecords;
    }

    public static class CaptureWorkflow
    {
        public const int MaxRefreshMinutes = 30;
        public const string RefreshButtonText = "起動し直さず、同じ記録を読み直す";
        public const string FinishButtonText = "CrashReport生成完了 / 起動確認後 → 読み取る";
        public const string MissingRecordHint = "記録0件は起動成功ではありません。CrashReport生成中なら完了まで待ち、ゲームを起動し直さず『同じ記録を読み直す』を押してください。";

        public static bool CanRefresh(Snapshot previous, DateTime now)
        {
            return previous != null && now.Kind == DateTimeKind.Utc && now >= previous.EndUtc &&
                Rules.ValidWindow(previous.StartUtc, now, now) &&
                now - previous.StartUtc <= TimeSpan.FromMinutes(MaxRefreshMinutes);
        }

        public static bool TryCommit(Snapshot captured, Snapshot previous, Snapshot baseline,
            Guid expectedTarget, bool cancelled, CaptureMode mode, TrialOutcome outcome,
            out CaptureTransition transition)
        {
            transition = null;
            if (!WildsProfile.AcceptsCapture(captured, expectedTarget, cancelled) ||
                !Rules.ValidWindow(captured.StartUtc, captured.EndUtc, captured.EndUtc)) return false;
            if (previous != null && previous.TargetSession != expectedTarget) return false;
            if (mode == CaptureMode.Refresh)
            {
                if (!CanRefresh(previous, captured.EndUtc) || captured.StartUtc != previous.StartUtc ||
                    previous.AttemptId == Guid.Empty) return false;
            }
            else if (mode == CaptureMode.Retest)
            {
                if (previous == null || captured.StartUtc <= previous.EndUtc) return false;
            }
            else if ((mode != CaptureMode.InitialAttempt && mode != CaptureMode.InitialRecent) || previous != null) return false;

            bool refresh = mode == CaptureMode.Refresh;
            captured.AttemptId = refresh ? previous.AttemptId : Guid.NewGuid();
            captured.Origin = refresh ? previous.Origin : mode == CaptureMode.InitialRecent ? CaptureOrigin.RecentWindow : CaptureOrigin.TimedAttempt;
            captured.RefreshCount = refresh ? Math.Min(999, previous.RefreshCount + 1) : 0;
            // A later partial read must not remove a safety stop already observed in this session.
            captured.PriorRestartObserved |= previous != null && (previous.PriorRestartObserved ||
                previous.System.Events.Any(e => e.Kind == EventKind.UncleanRestart));
            transition = new CaptureTransition
            {
                Current = captured,
                Baseline = refresh ? baseline : mode == CaptureMode.Retest ? previous : null,
                Outcome = refresh ? outcome : TrialOutcome.NotTested,
                PreserveStepRecords = refresh || mode == CaptureMode.Retest
            };
            return true;
        }

        public static string Description(Snapshot s)
        {
            string origin = s.Origin == CaptureOrigin.TimedAttempt ? "起動前からの計測（実際の起動回数は本人確認）" :
                s.Origin == CaptureOrigin.RecentWindow ? "直近範囲の読み取り（複数の起動が含まれる可能性あり）" : "計測方法の記録なし";
            return "取得方法: " + origin + (s.RefreshCount > 0 ? " / 同じ記録の読み直し " + Math.Min(999, s.RefreshCount) + " 回。新しい再テストではありません" : "");
        }
    }
}
