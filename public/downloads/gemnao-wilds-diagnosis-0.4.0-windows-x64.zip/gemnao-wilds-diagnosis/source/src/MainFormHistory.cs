using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Gemnao.Diagnostics
{
    internal sealed partial class MainForm
    {
        private ActionJournal journal=new ActionJournal();
        private string retestActionId;
        private readonly CheckBox historyConsent=new CheckBox{Text="履歴をこのWindowsユーザー用に保存/読むことに同意する（任意。PCの読み取り同意とは別です）",AutoSize=true,MaximumSize=new Size(940,0)};
        private readonly ComboBox historyAction=Combo(WildsProfile.Steps.Select(x=>x.Title).ToArray());
        private readonly ComboBox historyState=Combo("実施の記録なし","内容を確認","自分で試した","見送った");
        private readonly ComboBox historyOutcome=Combo("結果未記録","解決・プレイできた（本人申告）","改善した（本人申告）","変わらない（本人申告）","悪化した（本人申告）","試していない（本人申告）","判断できない（本人申告）");
        private readonly Button recordHistory=Button("選択した手順と結果を記録");
        private readonly Button saveHistory=Button("このPCに履歴を保存");
        private readonly Button loadHistory=Button("保存した履歴を読む");
        private readonly Button clearHistory=Button("保存履歴をゴミ箱へ");
        private readonly Button feedbackExport=Button("改善報告用JSONを確認して保存");
        private readonly TextBox historyReport=ReadBox();
        private void BuildHistoryTab()
        {
            var page=new TabPage("5  実施履歴と改善報告"){AutoScroll=true};var grid=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,RowCount=4,Padding=new Padding(8)};
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));grid.RowStyles.Add(new RowStyle(SizeType.Absolute,240));grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var top=Flow();top.Controls.Add(Label("1. 準備画面でゲームを選んだ後、過去に試した手順もここで結果を記録できます。本人の回答と、同じ診断中に読み取れた設定の変化は区別します。ファイル検証や正常プレイの実施を自動証明しません。"));
            top.Controls.Add(Row(historyAction,historyState));top.Controls.Add(Row(historyOutcome,recordHistory));grid.Controls.Add(top,0,0);
            var privacy=Flow();privacy.Controls.Add(Label("2. 任意で履歴を保存できます。保存内容は固定の手順ID/状態/本人結果/限定した観測の分類だけ（最大64記録）。パス・アカウント・端末ID・生ログは保存しません。WindowsのLocalAppData内の専用フォルダに、現在のWindowsユーザーで保護して保存します。他PC/別の導入先との同一性は自動判定しません。"));privacy.Controls.Add(historyConsent);privacy.Controls.Add(Label("同意チェックだけでは保存されません。保存ボタンを押してください。読み込みも自動では行いません。"));privacy.Controls.Add(Row(saveHistory,loadHistory,clearHistory));grid.Controls.Add(privacy,0,1);
            grid.Controls.Add(historyReport,0,2);
            var bottom=Flow();bottom.Controls.Add(Label("3. 改善報告は別操作です。Web受付は公開準備中。この版は選別済みJSONをローカル保存するだけで、送信しません。公開後もサイトで読込み・確認・送信同意が必要です。"));bottom.Controls.Add(feedbackExport);var website=Button("Web受付は準備中（まだ送信できません）");website.Enabled=false;bottom.Controls.Add(website);grid.Controls.Add(bottom,0,3);page.Controls.Add(grid);tabs.TabPages.Add(page);
            Action resize=()=>{int width=Math.Max(350,page.ClientSize.Width-SystemInformation.VerticalScrollBarWidth-24);grid.Width=width;foreach(var flow in new[]{top,privacy,bottom}){flow.MaximumSize=new Size(width-20,0);foreach(Control c in flow.Controls)if(c is Label||c is CheckBox||c is FlowLayoutPanel)c.MaximumSize=new Size(width-40,0);}};page.SizeChanged+=(s,e)=>resize();resize();
            historyConsent.CheckedChanged+=(s,e)=>UpdateHistoryButtons();historyAction.SelectedIndexChanged+=(s,e)=>ShowHistoryAction();
            recordHistory.Click+=(s,e)=>{var step=WildsProfile.Steps[historyAction.SelectedIndex];var state=(StepState)historyState.SelectedIndex;var result=(ActionOutcome)historyOutcome.SelectedIndex;if(!ActionJournal.Consistent(state,result)){MessageBox.Show(this,"実施状態と結果の組合せを確認してください。改善/変わらない等は『自分で試した』、未実施なら『試していない』です。自動で実施済みにはしません。");return;}journal.Record(step.Id,state,result);states[step.Id]=state;RefreshResults();RefreshJournal();};
            saveHistory.Click+=(s,e)=>SaveJournal();loadHistory.Click+=(s,e)=>LoadJournal();clearHistory.Click+=(s,e)=>RecycleJournal();feedbackExport.Click+=(s,e)=>ShowFeedbackExport();RefreshJournal();
        }
        private void UpdateHistoryButtons()
        {
            bool idle=!busy&&!measureStart.HasValue;
            historyConsent.Enabled=historyAction.Enabled=historyState.Enabled=historyOutcome.Enabled=idle;recordHistory.Enabled=idle&&targetPath!=null;
            saveHistory.Enabled=idle&&historyConsent.Checked&&journal.Records.Count>0;loadHistory.Enabled=idle&&historyConsent.Checked&&targetPath!=null;clearHistory.Enabled=idle&&historyConsent.Checked;
            feedbackExport.Enabled=idle&&journal.Records.Any(x=>x.Outcome!=ActionOutcome.Unrecorded);
        }
        private void ShowHistoryAction()
        {
            if(historyAction.SelectedIndex<0)return;var r=journal.Latest(WildsProfile.Steps[historyAction.SelectedIndex].Id);
            historyState.SelectedIndex=r==null?0:(int)r.State;historyOutcome.SelectedIndex=r==null?0:(int)r.Outcome;
        }
        private void RefreshJournal(){historyReport.Text=ForTextBox(journal.Summary());ShowHistoryAction();UpdateHistoryButtons();}
        private void SaveJournal()
        {
            if(!historyConsent.Checked||busy||measureStart.HasValue)return;
            if(MessageBox.Show(this,"表示中の履歴を専用のローカル保存先に保存します。前の保存履歴があれば置き換えます。外部送信はしません。保存しますか？","履歴の保存",MessageBoxButtons.YesNo,MessageBoxIcon.Information,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            try{HistoryLocal.Save(journal);MessageBox.Show(this,"このWindowsユーザー用に履歴を保存しました。次回は同意して『保存した履歴を読む』で再開できます。");}catch{MessageBox.Show(this,"履歴を保存できませんでした。現在の画面の履歴は保持しています。保護や権限を変更して回避しないでください。");}
        }
        private void LoadJournal()
        {
            if(!historyConsent.Checked||busy||measureStart.HasValue)return;
            ActionJournal saved;try{saved=HistoryLocal.Load();}catch{MessageBox.Show(this,"保存履歴がない、読めない、別のWindowsユーザー用、または非対応/不正な形式です。現在の履歴は変更していません。");return;}
            using(var dialog=new Form{Text="保存履歴の内容を確認",Width=900,Height=650,StartPosition=FormStartPosition.CenterParent,Font=Font})
            {
                var text=ReadBox();text.Text=ForTextBox(saved.Summary());var bottom=Flow();bottom.Dock=DockStyle.Bottom;bottom.Controls.Add(Label("同じ問題の続きを本人が選ぶ操作です。現在のPC/インストールとの一致は自動検証しません。読み込むと未保存の手順記録を置き換え、取得済みの比較基準はクリアします（外部送信なし）。"));var okay=new CheckBox{Text="この履歴を今回の問題の参考として使う",AutoSize=true};var load=Button("確認した履歴を読む");load.Enabled=false;okay.CheckedChanged+=(s,e)=>load.Enabled=okay.Checked;load.Click+=(s,e)=>dialog.DialogResult=DialogResult.OK;bottom.Controls.Add(okay);bottom.Controls.Add(load);dialog.Controls.Add(text);dialog.Controls.Add(bottom);
                if(dialog.ShowDialog(this)!=DialogResult.OK)return;
            }
            journal=saved;states.Clear();foreach(var r in journal.Records)states[r.ActionId]=r.State;current=baseline=null;targetSession=Guid.NewGuid();retestActionId=pendingRetestActionId=null;updating=true;outcome.SelectedIndex=0;updating=false;plan.Clear();actions.Items.Clear();report.Clear();actionDetail.Clear();resultSummary.Text="保存履歴を参考として読みました。現在の状態はまだ取得していません。";RefreshJournal();UpdateButtons();
        }
        private void RecycleJournal()
        {
            if(!historyConsent.Checked||busy||measureStart.HasValue)return;
            if(MessageBox.Show(this,"このアプリ専用の保存履歴をWindowsのゴミ箱へ移します。Windowsの確認画面でも内容を確認してください。ゴミ箱へ移せず完全削除になる警告が出たら取り消してください。ゴミ箱は空にしません。画面内の履歴は保持します。実行しますか？","保存履歴をゴミ箱へ",MessageBoxButtons.YesNo,MessageBoxIcon.Information,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            try{HistoryLocal.RecycleSavedHistory();MessageBox.Show(this,"保存履歴をゴミ箱へ移しました。画面内の履歴を消す場合は『新しい診断を始める』を選びます。");}catch{MessageBox.Show(this,"ゴミ箱への移動を完了できませんでした。削除や権限昇格は試しません。画面内の履歴は保持しています。");}
        }
        private void ShowFeedbackExport()
        {
            var records=journal.Records.GroupBy(x=>x.ActionId).Select(g=>g.Last()).Where(x=>x.Outcome!=ActionOutcome.Unrecorded&&FeedbackExport.AllowedActions.Contains(x.ActionId)).ToArray();if(records.Length==0)return;
            using(var form=new Form{Text="改善報告用の選別JSON（保存のみ・まだ送信しません）",Width=960,Height=760,StartPosition=FormStartPosition.CenterParent,Font=Font})
            {
                var list=new CheckedListBox{Dock=DockStyle.Top,Height=150,CheckOnClick=true};foreach(var r in records)list.Items.Add(WildsProfile.Steps.First(x=>x.Id==r.ActionId).Title+" / "+ActionJournal.OutcomeText(r.Outcome),false);
                var preview=ReadBox();var bottom=Flow();bottom.Dock=DockStyle.Bottom;bottom.Controls.Add(Label("最大8手順を選択。JSONに出る全項目を確認します。選んだ対処からMODや追加ツールの利用が分かる/推測できる場合があり、完全匿名ではありません。名前/パス/端末ID/DLL名/生ログ/ZIP/履歴全文は含めません。観測変化は送らず、結果は本人申告として扱います。"));
                var symptom=Combo("症状は分からない","起動直後のクラッシュ","黒い画面","描画関連エラー","シェーダー準備中","ゲームプレイ中のクラッシュ");
                var environment=new CheckBox{Text="報告対象と現在のPC環境が同じだと自分で確認し、OS/GPU分類・ドライバー版も含める（任意）",AutoSize=true,Enabled=current!=null};var confirm=new CheckBox{Text="保存するJSON全文を確認しました",AutoSize=true};var save=Button("JSONをローカル保存（送信しない）");save.Enabled=false;string json=null;
                Action update=()=>{confirm.Checked=false;try{var selected=list.CheckedIndices.Cast<int>().Select(i=>records[i]).ToArray();json=FeedbackExport.Build(selected,current,environment.Checked,FeedbackExport.Symptoms[symptom.SelectedIndex]);preview.Text=ForTextBox(json);}catch{json=null;preview.Text="1〜8件の手順を選択してください。未記録の結果は勝手に補いません。";}save.Enabled=false;};
                list.ItemCheck+=(s,e)=>{confirm.Checked=false;save.Enabled=false;json=null;if(form.IsHandleCreated&&!form.IsDisposed)form.BeginInvoke((MethodInvoker)(()=>{if(!form.IsDisposed)update();}));};symptom.SelectedIndexChanged+=(s,e)=>update();environment.CheckedChanged+=(s,e)=>update();confirm.CheckedChanged+=(s,e)=>save.Enabled=confirm.Checked&&json!=null;
                save.Click+=(s,e)=>{using(var dialog=new SaveFileDialog{Filter="JSON (*.json)|*.json",FileName="gemnao-feedback.json",InitialDirectory=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),OverwritePrompt=true,AddExtension=true,RestoreDirectory=true}){if(dialog.ShowDialog(form)!=DialogResult.OK)return;try{if(!LocalGuard.Allowed(dialog.FileName,true))throw new IOException();using(var file=new FileStream(dialog.FileName,FileMode.Create,FileAccess.Write,FileShare.None)){byte[] data=new UTF8Encoding(false,true).GetBytes(json);file.Write(data,0,data.Length);}MessageBox.Show(form,"JSONを保存しました。送信はしていません。Web受付は公開準備中です。同期フォルダに保存した場合の同期は別です。");form.Close();}catch{MessageBox.Show(form,"保存できませんでした。権限や保護を変更せず、別のローカル保存先を選んでください。");}}};
                bottom.Controls.Add(symptom);bottom.Controls.Add(environment);bottom.Controls.Add(confirm);bottom.Controls.Add(save);form.Controls.Add(preview);form.Controls.Add(list);form.Controls.Add(bottom);update();form.ShowDialog(this);
            }
        }
    }
}
