using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gemnao.Diagnostics
{
    public enum GameKind { General, Wilds }
    public enum GameSymptom { Launch, Crash, BlackScreen, Freeze, LowFps, Stutter, Other }
    public enum GameStore { Unknown, Steam, Other }
    public enum GameScene { Unknown, Startup, Menu, Gameplay, Everywhere }
    public enum Frequency { Unknown, Always, Sometimes }
    public enum GraphicsTrial { Unrecorded, NotTried, Better, Same, Worse, Unsure }
    public sealed class GameAnswers
    {
        public GameSymptom Symptom;
        public GameStore Store;
        public GameScene Scene;
        public Frequency Frequency;
        public GraphicsTrial LowerGraphics;
        public WildsAnswers Shared = new WildsAnswers();
    }
    public static class GameProfile
    {
        public const string Guide="https://gemnao.pages.dev/guide/pc-game-crash";
        public const string PerformanceOfficial="https://support.microsoft.com/en-us/windows/experience/performance-optimization/tips-to-improve-pc-performance-in-windows";
        public static readonly string[] SymptomLabels={"起動できない","クラッシュ・途中で終了","黒い画面","フリーズ・応答しない","FPSが低い","カクつく・一瞬止まる","その他・分からない"};
        public static readonly string[] SceneLabels={"分からない","起動時","メニュー","プレイ中","どの場面でも"};
        public static readonly string[] FrequencyLabels={"分からない","毎回","ときどき"};
        public static readonly string[] GraphicsTrialLabels={"結果未記録","まだ試していない","画質を1項目下げると改善","変わらない","悪化した","判断できない"};
        public static string Name(GameKind kind){return kind==GameKind.Wilds?"Monster Hunter Wilds（本人が選んだ固有ルール）":"PCゲーム共通（ゲーム名は保存しません）";}
        public static string SymptomText(GameSymptom symptom){return Enum.IsDefined(typeof(GameSymptom),symptom)?SymptomLabels[(int)symptom]:"分からない";}
        public static bool Accepts(string path,GameKind kind){return Enum.IsDefined(typeof(GameKind),kind)&&Rules.IsLocalExe(path)&&SteamText.IsLocalDirectory(path)&&(kind!=GameKind.Wilds||WildsProfile.IsTarget(path));}
        public static bool UsesWildsRules(GameKind kind,GameSymptom symptom){return kind==GameKind.Wilds&&symptom==GameSymptom.Launch;}
        public static bool IsPerformance(GameSymptom symptom){return symptom==GameSymptom.LowFps||symptom==GameSymptom.Stutter;}
        private static GuideStep Copy(string id,string title,string instructions,string warning,string official)
        {return new GuideStep{Id=id,Title=title,Instructions=instructions,Warning=warning,GuideUrl=Guide,OfficialUrl=official};}
        public static readonly GuideStep[] Steps=Rules.Steps.Concat(new[]{
            Copy("game-context","選んだ本体・発生場面と公式情報を照合","ランチャーとゲーム本体が別なら、実際に終了/停止する本体EXEを配布元のローカルファイル画面で確認します。ゲーム公式の必要環境・既知問題・更新完了と、今回の場面を照合してください。以前動いた場合は直前に変えた設定を控えます。","本体を選べない保護されたゲーム/別の子EXEは、この版で自動追跡しません。権限や保護を変えて探しません。要件の自動合否判定はしません。",Rules.Steps[0].OfficialUrl),
            Copy("game-black-screen","黒画面がゲーム内かPC全体かを分ける","ゲームだけ黒いか、デスクトップも表示できないか、音やメニュー操作は続くかを確認します。ゲームに表示モード設定がある場合だけ、現在値を控え、公式手順でウィンドウ表示に1項目だけ変えて同じ場面を比較します。","画面が戻らないPC全体の異常では再現を止めます。レジストリや設定ファイルを書き換えず、変化がなければ元の表示設定へ戻してください。",Rules.Steps[2].OfficialUrl),
            Copy("game-freeze","ゲームの応答停止と処理待ちを分ける","ゲームのロード/シェーダー準備表示がある場合は公式の待ち時間を確認します。Windowsは動くか、同じ場面で止まるかを記録してください。応答停止1002があれば時刻を照合します。","ログなしでもフリーズを否定できません。保存中の強制終了や繰り返しの強制電源断は案内しません。PC全体が止まる場合は再テストを中止します。",PerformanceOfficial),
            Copy("game-performance","同じ場面で1項目だけ画質を比較","ゲーム内のFPS表示があれば本人が値を控え、同じ解像度・同じ場面・同じ長さで確認します。現在の設定を控え、ゲームが提供する画質設定を1項目だけ下げて比較してください。結果を準備画面の質問と実施履歴に記録できます。","このツールはFPS/フレーム時間/温度/使用率を計測していません。改善してもGPU不足の証明ではありません。効果がなければ設定を戻します。電力・電圧・BIOSは変更しません。",PerformanceOfficial),
            Copy("game-stutter","カクつく条件と処理待ちを確認","初回の場所だけか、同じ場面を再度通っても続くか、ロード/シェーダー準備表示があるかを本人が控えます。ゲーム公式の案内と照合し、安全な同じ短い場面だけで比較します。","シェーダーキャッシュやセーブを削除しません。シェーダーが原因と決めず、継続する場合は公式窓口へ場面を伝えます。フレーム時間の自動測定は未対応です。",PerformanceOfficial),
            Copy("game-capture","利用中の録画/オーバーレイを1つずつ比較","利用していると本人が分かっている録画/オーバーレイだけ、元の状態を控え、通常の終了/公式設定で1つだけ止めた条件と比較します。","このツールは他アプリを検出/終了しません。改善しなかった条件は繰り返さず、必要なら元に戻します。存在だけで原因ではありません。", "https://help.steampowered.com/en/faqs/view/3978-072C-18DF-FBF9"),
            Copy("game-mods","追加ツールの導入元と対応版を確認","MOD/描画追加ツールを使っていると本人が分かる場合だけ、ゲーム版への対応と提供元の安全な戻し方を確認します。","この共通コースはゲームフォルダの追加物を走査しません。不明なDLLを削除せず、セーブを保護し、同時に複数を変更しません。",Rules.Steps[0].OfficialUrl),
            Copy("game-compatibility","互換モード/管理者実行の登録を確認","選択EXEのプロパティの互換性画面を自分で見て、表示した登録値と照合します。ゲーム提供元が必要とする設定を確認してください。","登録の存在は原因や現在の権限の証明ではありません。一般ゲームへ一律に設定解除/管理者実行を勧めません。ツールは昇格しません。",Rules.Steps[0].OfficialUrl),
            Copy("game-steam-client","Steam側の追加構成を導入元と照合","選択したSteam直下の既知名と、実行中Steamの読込み先を区別します。追加物と分かる場合だけ、導入元/提供元と安全な無効化・復元方法を確認します。","Wildsの1事例は他ゲームの原因を証明しません。存在/Hidden属性/読込みだけで悪質・故障・原因とは判定せず、名前だけで削除/リネームしません。System32/SysWOW64内は変更しません。",Rules.Steps[0].OfficialUrl),
            Copy("game-records","記録を保管してゲームの公式窓口へ","同じ失敗した手順を繰り返さず、選別済みレポートと本人が分かる症状・場面・試した結果を確認し、必要部分だけ公式窓口へ本人が渡します。","すべてのゲーム固有障害を解析できません。一般ゲームの生ログ/ZIP/ダンプは読みません。アカウント/通信/音声/コントローラー等はこの版の専用解析対象外です。",Rules.Steps[0].OfficialUrl)
        }).ToArray();
        public static GuideStep[] Catalog(GameKind kind,GameSymptom symptom){return UsesWildsRules(kind,symptom)?WildsProfile.Steps:Steps;}
        public static readonly GuideStep[] AllSteps=Steps.Concat(WildsProfile.Steps).ToArray();
        public static List<ActionPlanItem> Plan(Snapshot s,GameAnswers a)
        {
            if(UsesWildsRules(s.Game,a.Symptom))return WildsProfile.Plan(s,a.Shared);
            var plan=new List<ActionPlanItem>();
            Action<string,string> add=(id,why)=>{if(!plan.Any(x=>x.Step.Id==id))plan.Add(new ActionPlanItem{Step=Steps.First(x=>x.Id==id),Reason=why});};
            if(!WildsProfile.MayRetest(s,a.Shared)){add("stop","PC全体の異常の申告または記録があります。原因未確定でも再現を優先しません。");add("game-records","再現せず、取得済みの記録を保管します。");return plan;}
            if(a.Symptom==GameSymptom.Other){add("game-context","この症状の専用判定は未対応です。共通事実は取得できます。");add("game-records","症状に合う公式窓口で追加確認が必要です。");return plan;}
            if(a.Symptom==GameSymptom.BlackScreen)add("game-black-screen","本人が黒画面と申告。画面や描画処理を自動観測しての断定ではありません。");
            if(a.Symptom==GameSymptom.Freeze)add("game-freeze","本人が応答停止と申告。ロード待ちとPC全体の停止は別に確認します。");
            if(IsPerformance(a.Symptom))
            {
                if(a.Symptom==GameSymptom.Stutter)add("game-stutter","本人がカクつきと申告。Windowsエラー件数だけでは性能を評価できません。");
                if(a.LowerGraphics==GraphicsTrial.Unrecorded||a.LowerGraphics==GraphicsTrial.NotTried)add("game-performance","同条件での画質比較が未記録です。推測だけで部品交換を勧めません。");
                else add("game-context","画質比較の本人結果あり。実施済みの同じ条件を繰り返さず、場面と公式要件を照合します。");
            }
            foreach(var finding in Rules.Analyze(s))
            {
                if(finding.StepId=="observe")continue;
                if(finding.StepId=="files"&&a.Store!=GameStore.Steam)continue;
                add(finding.StepId,finding.Evidence+" "+finding.Unknown);
            }
            if(a.Store==GameStore.Steam&&(s.Steam.Files.Any(x=>x.State==TraceState.Present)||s.Steam.Modules.Any(x=>x.Location==ModuleLocation.SteamRoot)))add("game-steam-client","追加同意の範囲でSteam側の存在/読込みを観測。ゲーム側への読込みや原因は別です。");
            if(a.Shared.CaptureTools==Answer.Yes)add("game-capture","本人が併用していると回答しています。");
            if(a.Shared.Mods==Answer.Yes)add("game-mods","本人が追加ツールを使っていると回答しています。");
            if(s.Wilds.GameCompatibility||s.Wilds.GameAdminFlag)add("game-compatibility","選択EXEに関連する登録フラグあり。必要な設定かはゲーム公式で確認します。");
            if(a.Store==GameStore.Steam&&(a.Shared.Verification==VerifyResult.NotDone||a.Shared.Verification==VerifyResult.Unknown)&&!IsPerformance(a.Symptom))add("files","配布ファイルの検証結果が未確認。破損を検出したわけではありません。");
            if(a.Symptom==GameSymptom.BlackScreen||IsPerformance(a.Symptom))add("graphics","実際の版と公式既知問題を照合する候補です。最新版や故障を自動判定していません。");
            add("game-context","ゲーム本体・場面・必要環境を照合し、未取得の条件を補います。");add("game-records","改善しない場合は取得範囲外の確認が必要です。記録ゼロは正常の証明ではありません。");return plan;
        }
        public static string Summary(Snapshot s,GameAnswers a,IDictionary<string,StepState> states)
        {
            var b=new StringBuilder("【PCゲーム診断・共通の入口】\n");b.AppendLine("ルール: "+Name(s.Game)+" / 症状（本人申告）: "+SymptomText(a.Symptom));
            b.AppendLine("配布元（本人申告）: "+(a.Store==GameStore.Steam?"Steam":a.Store==GameStore.Other?"Steam以外":"分からない")+" / 場面: "+SceneLabels[(int)a.Scene]+" / 頻度: "+FrequencyLabels[(int)a.Frequency]);
            b.AppendLine("過去に遊べた: "+WildsProfile.AnswerText(a.Shared.WorkedBefore)+" / 録画・オーバーレイ: "+WildsProfile.AnswerText(a.Shared.CaptureTools)+" / MOD: "+WildsProfile.AnswerText(a.Shared.Mods));
            if(IsPerformance(a.Symptom))b.AppendLine("画質比較（本人申告）: "+GraphicsTrialLabels[(int)a.LowerGraphics]+"\nFPS・フレーム時間・GPU使用率・温度は測定していません。性能改善は本人の同条件比較で記録します。取得時のRAM/容量はプレイ中の最大負荷ではありません。");
            if(UsesWildsRules(s.Game,a.Symptom))return b.Append(WildsProfile.Summary(s,a.Shared,states)).ToString();
            b.AppendLine("本体ファイル版: "+WildsProfile.GameVersionText(s.Wilds.GameVersionParts)+" / "+Rules.StatusText(s.Wilds.FileStatus));
            b.AppendLine("互換性登録の読取: "+Rules.StatusText(s.Wilds.CompatibilityStatus)+" / ゲームの互換フラグ: "+(s.Wilds.GameCompatibility?"あり":"なし又は未取得")+" / 管理者実行フラグ: "+(s.Wilds.GameAdminFlag?"あり":"なし又は未取得"));
            b.AppendLine("PC全体の異常（本人申告）: "+WildsProfile.AnswerText(a.Shared.WholePcIssue)+" / ファイル検証（本人申告）: "+WildsProfile.VerifyText(a.Shared.Verification));
            foreach(var item in Plan(s,a)){StepState state;if(states==null||!states.TryGetValue(item.Step.Id,out state))state=StepState.NotStarted;b.AppendLine("\n["+Rules.StateText(state)+"] "+item.Step.Title+"\n手掛かり: "+item.Reason+"\n"+item.Step.Instructions+"\n注意: "+item.Step.Warning+"\n公式: "+item.Step.OfficialUrl);}
            b.AppendLine("\n対応範囲: 選択したWindowsゲームEXEの1000/1002と、同時間帯の4101/41、取得時PC情報。別EXE・独自エンジンログ・FPS/通信/入力/音声・すべての原因の特定は未対応。一般ゲームのZIP/ダンプをWilds形式として読みません。");return b.ToString();
        }
    }
}
