using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Gemnao.Diagnostics
{
    public enum Answer { Unknown, No, Yes }
    public enum LaunchStage { ImmediateExit, CrashReporter, ShaderPreparation, GraphicsError, SecurityNotice, Other, UnhandledException }
    public enum VerifyResult { NotDone, Unknown, NoFilesReacquired, FilesReacquired }
    public sealed class WildsAnswers
    {
        public LaunchStage Stage;
        public Answer WorkedBefore;
        public Answer DemoWorked;
        public Answer CaptureTools;
        public Answer Mods;
        public Answer TexturePack;
        public Answer WholePcIssue;
        public VerifyResult Verification;
    }
    public sealed class WildsFacts
    {
        public ReadStatus TraceStatus = ReadStatus.NotRead;
        public readonly List<TraceFact> Traces = new List<TraceFact>();
        public ReadStatus HistoryStatus = ReadStatus.NotRead;
        public LaunchHistoryKind History;
        public ReadStatus FileStatus = ReadStatus.NotRead;
        public int[] GameVersionParts = new int[0];
        public ReadStatus CompatibilityStatus = ReadStatus.NotRead;
        public bool GameCompatibility;
        public bool SteamCompatibility;
        public bool GameAdminFlag;
        public ReadStatus CrashFolderStatus = ReadStatus.NotRead;
        public bool CrashFolderPresent;
        public int CrashFilesExamined;
        public int CrashFilesInWindow;
        public bool CrashLimitReached;
        public ReadStatus InstalledRamStatus = ReadStatus.NotRead;
        public long? InstalledRamMiB;
        public bool? Is64BitWindows;
    }
    public sealed class ActionPlanItem
    {
        public GuideStep Step;
        public string Reason;
    }
    public sealed class SteamEntry
    {
        // Full paths remain local, never exported. Discovery is optional and explicitly consented.
        public string GamePath;
        public string SteamExe;
    }
    public static class WildsProfile
    {
        public const string ExeName = "MonsterHunterWilds.exe";
        public const string AppId = "2246340";
        public const string CheckedOn = "2026-10-02";
        public const string Official = "https://steamcommunity.com/app/2246340/discussions/0/596267902352499417/";
        public const string Guide = "https://gemnao.pages.dev/games/monster-hunter-wilds/not-launching";
        public static string GameVersionText(int[] parts)
        {
            if (parts == null || parts.Length != 4 || parts.Any(x => x < 0 || x > 65535)) return "不明";
            return string.Join(" / ", parts.Select(x => x.ToString(CultureInfo.InvariantCulture))) + "（major / minor / build / revision）";
        }
        public static bool IsTarget(string path) { return Rules.IsLocalExe(path) && string.Equals(Rules.FileName(path), ExeName, StringComparison.OrdinalIgnoreCase); }
        public static bool HasCompatibilityFlag(string value)
        {
            return Regex.IsMatch(value ?? "", @"(?:\A|\s)(?:WIN95|WIN98|WIN2000|WINXPSP2|WINXPSP3|VISTARTM|VISTASP1|VISTASP2|WIN7RTM|WIN8RTM)(?:\s|\z)", RegexOptions.IgnoreCase);
        }
        public static bool HasAdminFlag(string value) { return Regex.IsMatch(value ?? "", @"(?:\A|\s)RUNASADMIN(?:\s|\z)", RegexOptions.IgnoreCase); }
        public static readonly GuideStep[] Steps = {
            new GuideStep { Id="wilds-steam-client-review", Title="Steam側の追加構成を導入元と照合", Instructions="Steam直下の存在と、実行中Steamへの読込みを別々に確認します。ゲーム側の整合性確認だけでSteam本体側の追加物がなくなるとは限りません。身に覚えのない構成は、導入元/提供者と照合してください。追加物と確認できた場合だけ、元の構成と戻し方を保管し、提供元の安全な無効化方法を確認して、Steamを通常終了・再起動した条件と比較します。", Warning="名前だけで削除/リネームしません。WindowsのSystem32/SysWOW64内のDLLは変更しません。複数の変更で改善しても単独DLLの原因とは確定できません。このツールはSteamの終了・移動・設定変更をしません。", GuideUrl=Guide, OfficialUrl=Official },
            new GuideStep { Id="wilds-stop", Title="PC全体の異常があるので再現を止める", Instructions="電源断・再起動・ブルースクリーン・異常な発熱がある場合、ゲームの再起動テストは行いません。作業を保存し、PCメーカー/修理窓口に現象を相談します。", Warning="Kernel-Power 41だけで電源やCPUの故障とは判定しません。負荷テスト、BIOS、電圧変更は行いません。", GuideUrl=Guide, OfficialUrl="https://learn.microsoft.com/en-us/troubleshoot/windows-client/performance/event-id-41-restart" },
            new GuideStep { Id="wilds-security", Title="ブロック通知がある場合は保護履歴を確認", Instructions="Windows セキュリティ → ウイルスと脅威の防止 → 保護の履歴で、同じ時刻の対象を確認します。他社製品ならその検知履歴を確認。ゲーム本体か、MOD等の別ファイルかを区別します。", Warning="除外追加・許可・保護無効化はしません。関連する検知があればソフト提供元へ確認。個人情報を含む履歴を公開しないでください。", GuideUrl=Guide+"#security", OfficialUrl="https://support.microsoft.com/en-us/windows/security/windows-security/protection-history-in-the-windows-security-app" },
            new GuideStep { Id="wilds-compatibility", Title="互換モードが設定されているか確認", Instructions="Steam → ライブラリ → ワイルズを右クリック → 管理 → ローカルファイルを閲覧。MonsterHunterWilds.exe のプロパティ → 互換性で、元の値を控えます。互換モードが有効なら、そのチェックだけを外してSteamから比較するのが公式の案内です。変わらなければSteam.exeも同様に確認します。", Warning="このツールは設定を変更しません。管理者実行を追加しません。チェックが無効/管理されている場合は無理に変えず相談してください。戻す場合は控えた元の値へ。", GuideUrl=Guide, OfficialUrl=Official },
            new GuideStep { Id="wilds-admin-flag", Title="管理者実行の登録を現在の画面で照合", Instructions="ゲーム本体のプロパティ → 互換性で『管理者としてこのプログラムを実行する』の現在の状態を確認します。元の値を控え、通常の権限で変更できる場合に限り、このチェックだけを外したSteam起動と1回比較できます。変わらなければ実施済みと記録して次へ進みます。", Warning="登録値や過去のCrashReportのModeだけでは、現在のチェック状態・実効権限・原因を確定できません。自動変更や管理者昇格はしません。組織管理の設定や『すべてのユーザー』は変更しません。", GuideUrl=Guide, OfficialUrl=Official },
            new GuideStep { Id="wilds-mods", Title="自分で入れたMOD・描画ツールを確認", Instructions="MODを使用している場合は、導入履歴とセーブを保管し、使っている管理ツールの無効化/展開解除機能で元の構成と比較します。ReShadeや録画/性能表示ツールは、自分で起動したものだけ終了して比較します。", Warning="名前だけでDLLを削除しません。どれを追加したか分からなければこの作業は見送り。MODを外した状態で既存セーブを上書きしません。整合性確認だけで追加MODが全部消えるとは限りません。", GuideUrl=Guide+"#remove-mods", OfficialUrl=Official },
            new GuideStep { Id="wilds-capture", Title="録画/オーバーレイを終了した条件と1回比較", Instructions="併用していると回答したツールだけを対象にします。録画/配信を終えて保存し、自分で開いたOBS等を通常終了。他の条件を変えずSteamから1回起動します。変わらなければ今回の単独原因という仮説を弱め、元に戻して次の確認へ進みます。", Warning="画面に映っていた/導入されていたことはゲームへの介入や原因の証明ではありません。終了済みで失敗したなら同じ試験を繰り返しません。録画ツール等のプロセスを調査/終了しません。追加同意した場合のSteam本体だけが別の限定確認です。", GuideUrl=Guide+"#remove-mods", OfficialUrl="https://obsproject.com/kb/game-capture-source" },
            new GuideStep { Id="wilds-traces", Title="見つかった追加ツール名の痕跡を確認", Instructions="詳細の痕跡一覧を見て、導入元や自分で追加したかを確認します。ファイル名だけではゲーム付属か追加ツールかを決められません。身に覚えがなければ削除せず、公式サポート等に確認します。", Warning="存在、版メタデータ、ダンプの読込み一覧、原因は別々です。未導入という本人回答も保持します。保護無効化や未知DLLの実行はしません。", GuideUrl=Guide+"#remove-mods", OfficialUrl=Official },
            new GuideStep { Id="wilds-files", Title="Steamの整合性確認を1回行う", Instructions="ゲームを閉じ、Steamのダウンロードで更新が止まっていないか確認。ライブラリ → ワイルズを右クリック → プロパティ → インストール済みファイル → ゲームファイルの整合性を確認。再取得があればダウンロード完了を待ちます。結果を準備画面の選択肢に記録し、Steamのプレイから同じ起動を比較します。", Warning="再取得と起動改善は別です。セーブ/MODの状態を先に保管。検証を繰り返すだけにせず、同じ起動失敗が続いたら次へ進みます。", GuideUrl=Guide+"#verify-files", OfficialUrl="https://help.steampowered.com/ja/faqs/view/0C48-FCBD-DA71-93EB" },
            new GuideStep { Id="wilds-textures", Title="高解像度テクスチャDLCを確認", Instructions="Steam → ワイルズのプロパティ → DLCで、High Resolution Texture Packの有無を確認。導入後に不安定になった場合は、元のチェックを控え、このDLCだけチェックを外し、Steamを再起動して比較する公式手順があります。", Warning="公式条件は専用VRAM 16GB以上。共有GPUメモリを足しません。本ツールはVRAM容量/DLC導入を自動判定しません。16GB搭載でも今回の原因とは限りません。元に戻すと再ダウンロードが必要になる場合があります。", GuideUrl=Guide+"#check-vram", OfficialUrl=Official },
            new GuideStep { Id="wilds-driver", Title="実際のGPUドライバー版と公式情報を照合", Instructions="診断のGPU名/ドライバー版を確認し、カプコンのドライバー告知と、PC/GPUメーカーの対応情報を照合します。GPU/DirectXエラーや直前の更新がある場合は、その条件を記録します。", Warning="古い/新しいだけで原因としません。特定の版を固定推奨せず、このツールは更新・DDU・削除を実行しません。DirectXのWebインストーラーでDirectX12へ更新するという案内はしません。", GuideUrl=Guide+"#update-driver", OfficialUrl="https://store.steampowered.com/news/app/2246340/view/534357354429284375" },
            new GuideStep { Id="wilds-requirements", Title="公式の必要環境との未確認点を照合", Instructions="公式最低条件は64-bit Windows 10/11、RAM16GB、DirectX12、SSD/75GB、CPU i5-10400/i3-12100/Ryzen5 3600、GPU GTX1660 6GB/RX5500XT8GBです。取得したCPU/GPU名を手掛かりに公式条件と比較します。", Warning="型番の文字列だけで性能合否を自動判定しません。75GBは配布元の必要ストレージで、インストール済みPCに追加75GBの空きを要求する判定ではありません。SSD/VRAM/DirectX機能は未判定です。", GuideUrl="https://gemnao.pages.dev/games/monster-hunter-wilds/system-requirements", OfficialUrl="https://store.steampowered.com/app/2246340/" },
            new GuideStep { Id="wilds-records", Title="CrashReportと試した結果を保管して相談", Instructions="Steam → 管理 → ローカルファイルを閲覧 → CrashReportに、落ちた時刻に近いZIPがあれば保管します。このツールの選別済みレポートも内容確認後に保存できます。カプコンの公式窓口へ、Steamプレイ直後の状況、エラーの分類、ドライバー版、試した手順と結果を伝えます。", Warning="追加同意した場合だけZIP内の固定項目・例外・モジュールを読みます。生データは送信しません。生ログ・DxDiag・設定・ZIPは個人情報を含む場合があります。公式窓口から必要なものを求められた時だけ本人が確認して渡してください。", GuideUrl=Guide+"#crash-record", OfficialUrl="https://www.monsterhunter.com/support/wilds/" }
        };
        public static bool AcceptsCapture(Snapshot captured, Guid expectedTarget, bool cancelled)
        {
            return !cancelled && captured != null && expectedTarget != Guid.Empty && captured.TargetSession == expectedTarget;
        }
        public static int NextUntried(IList<ActionPlanItem> plan, IDictionary<string, StepState> states)
        {
            if (plan.Count > 0 && plan[0].Step.Id == "wilds-stop") return 0;
            for (int i=0; i<plan.Count; i++)
            {
                StepState state;
                if (!states.TryGetValue(plan[i].Step.Id, out state) || state == StepState.NotStarted || state == StepState.Checked) return i;
            }
            return -1;
        }
        public static bool MayRetest(Snapshot s, WildsAnswers a)
        {
            return a.WholePcIssue != Answer.Yes && (s == null || (!s.PriorRestartObserved && !s.System.Events.Any(e => e.Kind == EventKind.UncleanRestart)));
        }
        public static List<ActionPlanItem> Plan(Snapshot s, WildsAnswers a)
        {
            var plan = new List<ActionPlanItem>();
            Action<string, string> add = (id, reason) => { if (!plan.Any(x => x.Step.Id == id)) plan.Add(new ActionPlanItem { Step = Steps.First(x => x.Id == id), Reason = reason }); };
            if (a.WholePcIssue == Answer.Yes || s.PriorRestartObserved || s.System.Events.Any(e => e.Kind == EventKind.UncleanRestart))
            { add("wilds-stop", "本人の申告、今回またはこの診断内の先行取得にPC全体の終了記録があります。ゲームが原因とは未確定です。"); add("wilds-records", "安全な追加取得/相談に切り替えます。"); return plan; }
            if (SteamEvidence.NeedsReview(s.Steam)) add("wilds-steam-client-review", s.Steam.Modules.Any(x=>x.Location==ModuleLocation.SteamRoot)?"選択したSteamのプロセスで、既知名のDLLをSteam直下から読込む記録を観測しました。ゲームへの読込みや原因とは別です。":"選択したSteam直下に既知名の追加構成候補があります。存在だけで導入元・読込み・原因は未確定です。");
            if (a.Stage == LaunchStage.SecurityNotice) add("wilds-security", "本人が保護通知ありと申告。Windowsログだけでブロック原因は確定できません。");
            if(s.Wilds.GameAdminFlag) add("wilds-admin-flag", "現在のゲームEXEに管理者実行の登録を検出。まず実際の画面と照合し、通常権限との違いを確認する候補です。");
            if (s.Wilds.GameCompatibility || s.Wilds.SteamCompatibility) add("wilds-compatibility", "ローカル登録値に互換モードのフラグを検出。実際に適用されたか、原因かは未確定です。");
            if (a.CaptureTools == Answer.Yes) add("wilds-capture", "本人が録画/オーバーレイの併用を申告。存在や一覧だけで原因と決めず、未実施の場合だけ比較します。");
            if (TraceEvidence.HasTrace(s)) add("wilds-traces", "限定した場所に既知名の痕跡候補があります。MOD/ReShadeの導入や現在の稼働を確定していません。");
            if (a.Mods == Answer.Yes) add("wilds-mods", "本人がMOD/描画介入ツールの利用を申告。追加ファイルを検査しての断定ではありません。");
            if (s.Wilds.Is64BitWindows == false || (s.Wilds.InstalledRamMiB.HasValue && s.Wilds.InstalledRamMiB < 16384)) add("wilds-requirements", "取得できたOS/RAMの一部が公式条件と合っていない可能性があります。取得不足や予約領域も確認します。");
            if (a.Verification == VerifyResult.NotDone || a.Verification == VerifyResult.Unknown) add("wilds-files", "Steamからの起動直後の失敗なので、配布ファイルと更新完了を確認する一般的な候補です。破損を検出したという意味ではありません。");
            if (a.TexturePack == Answer.Yes) add("wilds-textures", "本人が高解像度DLCありと申告。VRAM不足やDLCが今回の原因とは断定していません。");
            if (a.Stage == LaunchStage.GraphicsError || a.Stage == LaunchStage.ShaderPreparation || s.Application.Events.Any(e => e.Module == ModuleKind.Graphics) || s.System.Events.Any(e => e.Kind == EventKind.DisplayRecovery)) add("wilds-driver", "描画関連の申告/記録があるため。Windowsの記録はドライバー故障の証明ではありません。");
            if (a.TexturePack == Answer.Unknown) add("wilds-textures", "DLCの有無が未確認です。まず導入状態を見るだけに留めます。");
            if (a.Mods == Answer.Unknown && s.Wilds.TraceStatus != ReadStatus.Complete) add("wilds-mods", "MOD/描画介入ツールの利用が未確認です。導入履歴を確認し、不明なファイルは触りません。");
            add("wilds-driver", "ファイル確認後も続く場合、実際の版と公式告知を照合します。取得した版の良否は自動判断していません。");
            add("wilds-records", "改善しない場合の相談先。記録ゼロでも正常とは判定しません。");
            return plan;
        }
        public static string Summary(Snapshot s, WildsAnswers a, IDictionary<string, StepState> states)
        {
            var b = new StringBuilder();
            b.AppendLine("【ワイルズ専用・Steamのプレイ直後に落ちる】");
            b.AppendLine("公式情報の確認日: " + CheckedOn + " / ネットで最新状況を自動照会しません");
            b.AppendLine("本人の申告: " + StageText(a.Stage) + " / 以前は動いた: " + AnswerText(a.WorkedBefore));
            b.AppendLine("録画/オーバーレイ（本人申告）: " + AnswerText(a.CaptureTools));
            b.AppendLine("MOD/描画ツール: " + AnswerText(a.Mods) + " / 高解像度DLC: " + AnswerText(a.TexturePack) + " / PC全体の異常: " + AnswerText(a.WholePcIssue));
            b.AppendLine("整合性確認（本人の記録）: " + VerifyText(a.Verification));
            var f = s.Wilds;
            b.AppendLine("\n読み取れた事実:");
            b.AppendLine("ゲームEXEのファイル版: " + GameVersionText(f.GameVersionParts) + " / " + Rules.StatusText(f.FileStatus) + "（ゲーム内バージョンと同一とは限りません）");
            b.AppendLine("64-bit Windows: " + (!f.Is64BitWindows.HasValue ? "未取得" : f.Is64BitWindows.Value ? "はい" : "いいえ"));
            b.AppendLine("搭載RAMモジュール合計: " + (f.InstalledRamMiB.HasValue ? f.InstalledRamMiB.Value.ToString(CultureInfo.InvariantCulture) + " MiB" : "不明") + " / " + Rules.StatusText(f.InstalledRamStatus));
            b.AppendLine("互換モード登録: ゲーム " + Flag(f.GameCompatibility, f.CompatibilityStatus) + " / Steam " + Flag(f.SteamCompatibility, f.CompatibilityStatus) + " / " + Rules.StatusText(f.CompatibilityStatus));
            if (f.GameAdminFlag) b.AppendLine("ゲームに管理者実行の登録があります。本ツールは昇格も設定変更も行いません。");
            b.AppendLine("CrashReport: " + (f.CrashFolderStatus != ReadStatus.Complete && f.CrashFolderStatus != ReadStatus.Partial ? "判定できません" : f.CrashFolderPresent ? "フォルダあり" : "フォルダなし") + " / " + Rules.StatusText(f.CrashFolderStatus));
            b.AppendLine("ZIPの更新時刻が観測範囲内: " + f.CrashFilesInWindow + " 件 / 調べたZIP " + f.CrashFilesExamined + " 件" + (f.CrashLimitReached ? " / 上限到達" : "") + "（件数/更新時刻のみの集計。内容の追加解析は別枠、対応は未確定）");
            b.AppendLine("\n次の一歩（1つずつ。下にあるほど後で確認）:");
            b.AppendLine("手順の状態はこの起動中の本人の記録です。『実施の記録なし』は未実施の証明ではありません。以前に試して改善しなかった操作を繰り返さないでください。");
            int n = 1;
            foreach (var item in Plan(s, a))
            {
                StepState state; if (states == null || !states.TryGetValue(item.Step.Id, out state)) state = StepState.NotStarted;
                b.AppendLine((n++) + ". " + item.Step.Title + " [" + Rules.StateText(state) + "]\n理由: " + item.Reason + "\n" + item.Step.Instructions + "\n注意: " + item.Step.Warning + "\n公式: " + item.Step.OfficialUrl + "\n");
            }
            b.AppendLine("まだ分からないこと: 必要GPU機能/専用VRAM、DLCの実導入、CPU/GPUの故障、セーブ内容、実際のMOD構成。メモリが多い/ファイル再取得なし/ログなしだけで正常や解決とはしません。");
            return b.ToString();
        }
        private static string Flag(bool value, ReadStatus status) { return value ? "あり" : status == ReadStatus.Complete ? "この範囲では見つからず" : "未確認"; }
        public static string AnswerText(Answer a) { return a == Answer.Yes ? "あり/はい" : a == Answer.No ? "なし/いいえ" : "分からない"; }
        public static string StageText(LaunchStage a)
        {
            switch(a) { case LaunchStage.UnhandledException: return "Unhandled exception / Crash の画面"; case LaunchStage.CrashReporter: return "CrashReport生成画面（ゲームの応答停止とは別）"; case LaunchStage.ShaderPreparation: return "シェーダー準備中"; case LaunchStage.GraphicsError: return "GPU/DirectX/メモリ関連の表示"; case LaunchStage.SecurityNotice: return "保護/ブロック通知"; case LaunchStage.Other: return "その他/分からない"; default: return "プレイ直後に終了・表示なし"; }
        }
        public static string VerifyText(VerifyResult a)
        {
            switch(a) { case VerifyResult.Unknown: return "実施結果は分からない"; case VerifyResult.NoFilesReacquired: return "実施・再取得なし"; case VerifyResult.FilesReacquired: return "実施・再取得あり（完了待ちを確認）"; default: return "実施の記録なし（未実施の証明ではない）"; }
        }
    }
    // Valve KeyValues-style syntax: closed, bounded parser for local Steam registration files.
    // Unknown/unsupported syntax fails closed; no macros, file includes, expression evaluation or code.
    public sealed class KvNode
    {
        public string Value;
        public readonly Dictionary<string, KvNode> Children = new Dictionary<string, KvNode>(StringComparer.OrdinalIgnoreCase);
        public string Text(string key) { KvNode n; return Children.TryGetValue(key, out n) ? n.Value : null; }
    }
    public static class SteamText
    {
        public static KvNode Parse(string text)
        {
            if (text == null || text.Length > 1048576) throw new FormatException("Registration file too large.");
            int pos=0, tokens=0;
            Func<string> token = () => {
                while(pos<text.Length) {
                    if(char.IsWhiteSpace(text[pos])) { pos++; continue; }
                    if(text[pos]=='/' && pos+1<text.Length && text[pos+1]=='/') { while(pos<text.Length && text[pos]!='\n')pos++; continue; }
                    break;
                }
                if(pos>=text.Length)return null;
                if(++tokens>8192)throw new FormatException("Too many tokens.");
                char c=text[pos++]; if(c=='{' || c=='}')return c.ToString();
                if(c!='"')throw new FormatException("Unsupported token.");
                var b=new StringBuilder();
                while(pos<text.Length) {
                    c=text[pos++]; if(c=='"')return "s:"+b;
                    if(c=='\\') { if(pos>=text.Length)throw new FormatException(); char next=text[pos++]; if(next=='\\' || next=='"')b.Append(next); else throw new FormatException("Unsupported escape."); }
                    else { if(char.IsControl(c))throw new FormatException(); b.Append(c); }
                    if(b.Length>4096)throw new FormatException("String too long.");
                }
                throw new FormatException("Unclosed string.");
            };
            Func<int,bool,KvNode> read=null;
            read=(depth,nested)=> {
                if(depth>8)throw new FormatException("Too deep.");
                var node=new KvNode();
                for(;;) {
                    string key=token(); if(key==null) { if(nested)throw new FormatException(); return node; }
                    if(key=="}") { if(!nested)throw new FormatException(); return node; }
                    if(!key.StartsWith("s:"))throw new FormatException();
                    string value=token(); if(value==null)throw new FormatException();
                    KvNode child;
                    if(value=="{")child=read(depth+1,true);
                    else if(value.StartsWith("s:"))child=new KvNode { Value=value.Substring(2) };
                    else throw new FormatException();
                    key=key.Substring(2); if(node.Children.ContainsKey(key))throw new FormatException("Duplicate key.");
                    node.Children.Add(key,child);
                }
            };
            return read(0,false);
        }
        public static string[] LibraryPaths(string text)
        {
            var root=Parse(text); KvNode libs;
            if(!root.Children.TryGetValue("libraryfolders",out libs))return new string[0];
            return libs.Children.Where(x=>Regex.IsMatch(x.Key,@"\A[0-9]{1,3}\z")).Select(x=>x.Value.Value ?? x.Value.Text("path"))
                .Where(IsLocalDirectory).Distinct(StringComparer.OrdinalIgnoreCase).Take(16).ToArray();
        }
        public static string NormalizeLocalPath(string path)
        {
            if (!IsLocalDirectory(path)) return null;
            return char.ToUpperInvariant(path[0]) + path.Substring(1).Replace('/', '\\');
        }
        public static bool IsLocalDirectory(string path)
        {
            if(path==null || path.Length>240 || !Regex.IsMatch(path,@"\A[A-Za-z]:[\\/]"))return false;
            if(path.Substring(3).IndexOfAny(new[]{':','\0','*','?','"','<','>','|'})>=0 || path.Any(char.IsControl))return false;
            return !path.Replace('/','\\').Split('\\').Any(x=>x==".." || x==".");
        }
        public static string InstallDirectory(string text)
        {
            var root=Parse(text); KvNode app;
            if(!root.Children.TryGetValue("AppState",out app) || app.Text("appid")!=WildsProfile.AppId)return null;
            string name=app.Text("installdir");
            if(string.IsNullOrWhiteSpace(name) || name.Length>120 || name=="." || name==".." || name.EndsWith(".") || name.EndsWith(" ") || name.IndexOfAny(new[]{'\\','/',':','\0','*','?','"','<','>','|'})>=0 || name.Any(char.IsControl))return null;
            return name;
        }
    }
}
