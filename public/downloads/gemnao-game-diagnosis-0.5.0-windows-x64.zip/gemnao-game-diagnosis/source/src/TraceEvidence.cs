using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Gemnao.Diagnostics
{
    public enum TraceId { DirectInputProxy,DxgiProxy,D3d11Proxy,VersionProxy,ReShadeConfig,ReShadeShaders,ReFrameworkDirectory }
    public enum TraceState { Unknown,Absent,Present,Denied,Unsupported }
    public enum ProductMark { None,ReShade,ReFramework }
    public enum LaunchHistoryKind { Unknown,NoUsefulValue,TimestampValue,Invalid }
    public sealed class TraceDefinition { public TraceId Id;public string Name;public bool Directory,Dll; }
    public sealed class TraceFact { public TraceId Id;public TraceState State;public ProductMark Marker; }
    public static class TraceEvidence
    {
        public static readonly TraceDefinition[] KnownFiles={
            new TraceDefinition{Id=TraceId.DirectInputProxy,Name="dinput8.dll",Dll=true},new TraceDefinition{Id=TraceId.DxgiProxy,Name="dxgi.dll",Dll=true},new TraceDefinition{Id=TraceId.D3d11Proxy,Name="d3d11.dll",Dll=true},new TraceDefinition{Id=TraceId.VersionProxy,Name="version.dll",Dll=true},
            new TraceDefinition{Id=TraceId.ReShadeConfig,Name="ReShade.ini"},new TraceDefinition{Id=TraceId.ReShadeShaders,Name="reshade-shaders",Directory=true},new TraceDefinition{Id=TraceId.ReFrameworkDirectory,Name="reframework",Directory=true}
        };
        public static ProductMark ProductMarker(string product,string description)
        {
            if(new[]{product,description}.Any(x=>string.Equals(x,"ReShade",StringComparison.OrdinalIgnoreCase)))return ProductMark.ReShade;
            if(new[]{product,description}.Any(x=>string.Equals(x,"REFramework",StringComparison.OrdinalIgnoreCase)))return ProductMark.ReFramework;
            return ProductMark.None;
        }
        public static LaunchHistoryKind LaunchHistory(string text,DateTime nowUtc)
        {
            KvNode app;var root=SteamText.Parse(text);
            if(!root.Children.TryGetValue("AppState",out app)||app.Text("appid")!=WildsProfile.AppId)return LaunchHistoryKind.Unknown;
            string value=app.Text("LastPlayed");if(string.IsNullOrEmpty(value)||value=="0")return LaunchHistoryKind.NoUsefulValue;
            ulong seconds;if(!Regex.IsMatch(value,@"\A[0-9]{9,10}\z")||!ulong.TryParse(value,out seconds))return LaunchHistoryKind.Invalid;
            try{var time=new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddSeconds(seconds);return time<=nowUtc.AddDays(1)?LaunchHistoryKind.TimestampValue:LaunchHistoryKind.Invalid;}catch{return LaunchHistoryKind.Invalid;}
        }
        public static bool HasTrace(Snapshot s) { return s.Wilds.Traces.Any(x=>x.State==TraceState.Present); }
        public static string Summary(Snapshot s,WildsAnswers a)
        {
            var b=new StringBuilder("\n【追加の痕跡・成功履歴の確認】\n");
            b.AppendLine("製品版で遊べた（本人申告）: "+WildsProfile.AnswerText(a.WorkedBefore)+" / 体験版・βで遊べた（本人申告）: "+WildsProfile.AnswerText(a.DemoWorked));
            b.AppendLine("体験版の成功は現在の製品版の成功/互換性の証明ではありません。記録だけで起動成功を決めず、この2つを分けます。");
            b.AppendLine("ゲーム直下の既知の痕跡: "+Rules.StatusText(s.Wilds.TraceStatus));
            foreach(var def in KnownFiles)
            {
                var f=s.Wilds.Traces.FirstOrDefault(x=>x.Id==def.Id);if(f==null)continue;
                string state=f.State==TraceState.Present?"存在を確認":f.State==TraceState.Absent?"この場所には見つからず":f.State==TraceState.Denied?"アクセス拒否":"未確認/非対応";
                string mark=f.Marker==ProductMark.ReShade?" / 版メタデータの製品名はReShade":f.Marker==ProductMark.ReFramework?" / 版メタデータの製品名はREFramework":"";
                b.AppendLine("  "+def.Name+": "+state+mark);
            }
            b.AppendLine("名前/メタデータの痕跡と、導入された履歴・実際の読込み・今回の原因は別です。DLL名だけでMODと断定せず、未知ファイルを削除しません。未検出でも『一度も入れたことがない』とは証明できません。");
            string history=s.Wilds.History==LaunchHistoryKind.TimestampValue?"LastPlayedに時刻形式の値あり（失敗した起動も含み得る）":s.Wilds.History==LaunchHistoryKind.NoUsefulValue?"LastPlayedに利用できる値なし（未起動の証明ではない）":"利用できる履歴は未確認";
            b.AppendLine("製品版のSteam登録: "+history+" / "+Rules.StatusText(s.Wilds.HistoryStatus));
            b.AppendLine("SteamのアカウントIDやuserdata、体験版の個人ファイルは調べません。LastPlayedの値/時刻は出力しません。");return b.ToString();
        }
    }
}
