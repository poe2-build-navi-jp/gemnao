using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gemnao.Diagnostics
{
    public enum SteamItemId { OpenSteamTool, CloudRedirect, Dwmapi, Xinput14, LocalDwmapi, ToolConfig }
    public enum ModuleLocation { Unknown, SteamRoot, WindowsSystem, Other }
    public enum SteamObservation { Unknown, RootModuleObserved, KnownSystemOnly, KnownModulesNotListed }
    public sealed class SteamItemDefinition { public SteamItemId Id; public string Name; public bool Module; }
    public sealed class SteamFileFact { public SteamItemId Id; public TraceState State; public bool Hidden; }
    public sealed class SteamModuleFact { public SteamItemId Id; public ModuleLocation Location; }
    public sealed class SteamModuleContext
    {
        // Transient comparison context only; never attached to an export or saved history.
        public string SteamRoot,WindowsSystem,WindowsX86;
    }
    public sealed class SteamFacts
    {
        public ReadStatus FileStatus=ReadStatus.NotRead, ProcessStatus=ReadStatus.NotRead;
        public bool RootSelected, MatchingProcessFound, ProcessLimitReached, ModuleLimitReached;
        public readonly List<SteamFileFact> Files=new List<SteamFileFact>();
        public readonly List<SteamModuleFact> Modules=new List<SteamModuleFact>();
    }
    public static class SteamEvidence
    {
        public static readonly SteamItemDefinition[] Items={
            new SteamItemDefinition{Id=SteamItemId.OpenSteamTool,Name="OpenSteamTool.dll",Module=true},
            new SteamItemDefinition{Id=SteamItemId.CloudRedirect,Name="cloud_redirect.dll",Module=true},
            new SteamItemDefinition{Id=SteamItemId.Dwmapi,Name="dwmapi.dll",Module=true},
            new SteamItemDefinition{Id=SteamItemId.Xinput14,Name="xinput1_4.dll",Module=true},
            new SteamItemDefinition{Id=SteamItemId.LocalDwmapi,Name="localdwmapi.dll",Module=true},
            new SteamItemDefinition{Id=SteamItemId.ToolConfig,Name="opensteamtool.toml"}
        };
        public static SteamItemDefinition Known(string name) { return Items.FirstOrDefault(x=>string.Equals(x.Name,name,StringComparison.OrdinalIgnoreCase)); }
        private static string Full(string path)
        {
            if(!SteamText.IsLocalDirectory(path))return null;
            return SteamText.NormalizeLocalPath(path)?.TrimEnd('\\').ToUpperInvariant();
        }
        public static ModuleLocation ClassifyLocation(string fullModulePath,string steamRoot,string windowsSystem,string windowsSystem32)
        {
            string p=Full(fullModulePath),root=Full(steamRoot),system=Full(windowsSystem),system32=Full(windowsSystem32);
            if(p==null||(root==null&&system==null&&system32==null))return ModuleLocation.Unknown;
            int split=p.LastIndexOf('\\');if(split<3)return ModuleLocation.Unknown;
            string parent=p.Substring(0,split);
            if(root!=null && parent==root)return ModuleLocation.SteamRoot;
            if((system!=null&&parent==system)||(system32!=null&&parent==system32))return ModuleLocation.WindowsSystem;
            return ModuleLocation.Other;
        }
        public static void AddModule(SteamFacts facts,string name,string path,string steamRoot,string system,string system32)
        {
            var def=Known(name);if(def==null||!def.Module)return;
            var location=ClassifyLocation(path,steamRoot,system,system32);
            if(!facts.Modules.Any(x=>x.Id==def.Id&&x.Location==location))facts.Modules.Add(new SteamModuleFact{Id=def.Id,Location=location});
        }
        public static SteamObservation Observation(SteamFacts facts)
        {
            if(facts.Modules.Any(x=>x.Location==ModuleLocation.SteamRoot))return SteamObservation.RootModuleObserved;
            if(facts.ProcessStatus!=ReadStatus.Complete||!facts.MatchingProcessFound||facts.ProcessLimitReached||facts.ModuleLimitReached)return SteamObservation.Unknown;
            if(facts.Modules.Any(x=>x.Location==ModuleLocation.Other||x.Location==ModuleLocation.Unknown))return SteamObservation.Unknown;
            return facts.Modules.Count>0?SteamObservation.KnownSystemOnly:SteamObservation.KnownModulesNotListed;
        }
        public static bool NeedsReview(SteamFacts facts) { return facts.Files.Any(x=>x.State==TraceState.Present)||facts.Modules.Any(x=>x.Location==ModuleLocation.SteamRoot); }
        public static string LocationText(ModuleLocation location)
        {
            return location==ModuleLocation.SteamRoot?"選択したSteam直下":location==ModuleLocation.WindowsSystem?"WindowsのSystem32/SysWOW64":location==ModuleLocation.Other?"その他の場所（パス非表示）":"場所不明";
        }
        public static string ObservationText(SteamObservation observation)
        {
            return observation==SteamObservation.RootModuleObserved?"既知名のDLLをSteam直下から読込む記録あり":observation==SteamObservation.KnownSystemOnly?"今回照合した既知名はWindowsシステム側のみで観測":observation==SteamObservation.KnownModulesNotListed?"今回のSteam一覧に既知5名は見つからず":"不明/未確認";
        }
        public static string Summary(SteamFacts facts)
        {
            var b=new StringBuilder("\n【追加確認: Steam側の限定した構成】\n");
            b.AppendLine("選択したSteam直下の既知6項目: "+Rules.StatusText(facts.FileStatus));
            foreach(var f in facts.Files)
            {
                var d=Items.FirstOrDefault(x=>x.Id==f.Id);if(d==null)continue;
                b.AppendLine("  "+d.Name+": "+(f.State==TraceState.Present?"存在 / Hidden属性 "+(f.Hidden?"あり":"なし"):f.State==TraceState.Absent?"この場所に見つからず":f.State==TraceState.Denied?"アクセス拒否":"未確認/非対応"));
            }
            b.AppendLine("選択本体パスと一致した実行中Steamのモジュール: "+Rules.StatusText(facts.ProcessStatus));
            foreach(var m in facts.Modules)
            {
                var d=Items.FirstOrDefault(x=>x.Id==m.Id);if(d==null||!d.Module)continue;
                b.AppendLine("  "+d.Name+": Steam内に観測 / "+LocationText(m.Location));
            }
            b.AppendLine(ObservationText(Observation(facts)));
            b.AppendLine("ファイルの存在/Hidden属性、Steamへの読込み、ゲームへの読込み、クラッシュ原因は別々です。名前だけで不正・有害・原因とは判定しません。HiddenはWindowsの属性で、隠された意図は判断できません。");
            b.AppendLine("ゲーム側の一覧は追加同意したCrashReportの別時点の資料です。Steam側の読込みをゲームへの読込みとみなしません。読み取れない/一覧にない場合も全時点の不在証明ではありません。設定本文・アカウント・他アプリの一覧は保存しません。");
            return b.ToString();
        }
    }
}
