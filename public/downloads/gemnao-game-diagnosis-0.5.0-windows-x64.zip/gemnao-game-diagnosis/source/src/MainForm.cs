using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gemnao.Diagnostics
{
    internal sealed partial class MainForm : Form
    {
        private string targetPath, steamExe;
        private GameKind selectedGame;
        private GameSymptom selectedSymptom;
        private GameStore selectedStore;
        private readonly ComboBox profile=Combo("PCゲーム共通（通常はこちら）","Monster Hunter Wilds Steam版の固有ルール");
        private readonly ComboBox symptom=Combo(GameProfile.SymptomLabels);
        private readonly ComboBox store=Combo("配布元が分からない","Steam","Steam以外");
        private readonly ComboBox scene=Combo(GameProfile.SceneLabels);
        private readonly ComboBox frequency=Combo(GameProfile.FrequencyLabels);
        private readonly ComboBox lowerGraphics=Combo(GameProfile.GraphicsTrialLabels);
        private string pendingRetestActionId;
        private Guid targetSession;
        private Snapshot current, baseline;
        private DateTime? measureStart;
        private bool busy, updating, measurementIsRetest, sessionRestartObserved;
        private CancellationTokenSource cancellation;
        private List<ActionPlanItem> plan = new List<ActionPlanItem>();
        private readonly Dictionary<string, StepState> states = new Dictionary<string, StepState>();
        private readonly TabControl tabs = new TabControl { Dock=DockStyle.Fill };
        private readonly CheckBox traceConsent = new CheckBox { Text="Wildsのみ追加確認: ゲーム直下の既知7項目の痕跡/版情報と、製品版登録のLastPlayedを読む（導入歴/成功は断定しません）",AutoSize=true,MaximumSize=new Size(940,0) };
        private readonly CheckBox archiveConsent = new CheckBox { Text="Wildsのみ追加確認: CrashReportのZIPを1個読む（最大8MiB。固定テキストと例外/モジュールのみ。生データは共有しません）",AutoSize=true,MaximumSize=new Size(940,0) };
        private readonly CheckBox steamConsent = new CheckBox { Text="追加確認: 選択したSteam直下の既知6項目/Hidden属性と、実行中Steamの既知5DLLの読込先を調べる（原因は断定しません）",AutoSize=true,MaximumSize=new Size(940,0) };
        private readonly Button chooseSteam = Button("Steam本体を自分で選ぶ（追加確認用）");
        private readonly Button reread = Button(CaptureWorkflow.RefreshButtonText);
        private readonly Button rereadFromActions = Button(CaptureWorkflow.RefreshButtonText);
        private readonly Button pickArchive = Button("別のCrashReport ZIPを選んで読む");
        private readonly CheckBox consent = new CheckBox { Text="読み取り範囲を確認し、このPC内での取得に同意する", AutoSize=true };
        private readonly Button find = Button("Steamの登録先からワイルズを探す");
        private readonly Button choose = Button("自分で本体EXEを選ぶ");
        private readonly Button reset = Button("新しい診断を始める");
        private readonly Label targetLabel = Label("ゲーム未選択");
        private readonly ComboBox stage = Combo(WildsProfile.StageText(LaunchStage.ImmediateExit),WildsProfile.StageText(LaunchStage.CrashReporter),WildsProfile.StageText(LaunchStage.ShaderPreparation),WildsProfile.StageText(LaunchStage.GraphicsError),WildsProfile.StageText(LaunchStage.SecurityNotice),WildsProfile.StageText(LaunchStage.Other),WildsProfile.StageText(LaunchStage.UnhandledException));
        private readonly ComboBox worked = Combo("分からない","製品版で遊べたことはない","製品版では以前遊べた");
        private readonly ComboBox demo = Combo("分からない","体験版/βで遊べたことはない","体験版/βでは遊べた");
        private readonly ComboBox capture = Combo("分からない","録画/オーバーレイは併用していない","録画/オーバーレイを併用している");
        private readonly ComboBox mods = Combo("分からない","使っていない","MOD/描画ツールを使っている");
        private readonly ComboBox textures = Combo("分からない","高解像度DLCなし","高解像度DLCあり");
        private readonly ComboBox pcIssue = Combo("分からない","ゲームの症状だけ・PCは動く","PCも電源断/再起動/ブルースクリーン/完全停止");
        private readonly ComboBox verify = Combo("実施の記録なし","実施結果は分からない","実施・再取得なし","実施・再取得あり（完了済み）");
        private readonly Button begin = Button("症状を確認する直前 → 記録開始");
        private readonly Button recent = Button("すでに症状が出た場合: 直近10分を読む");
        private readonly Button finish = Button(CaptureWorkflow.FinishButtonText);
        private readonly Button cancel = Button("中止する");
        private readonly Label progress = Label("1 / 準備。Windows x64専用。まだPC情報を取得していません");
        private readonly Label measureLabel = Label("計測開始後、普段の配布元からゲームを起動し、選んだ症状の場面を1回だけ確認します。");
        private readonly Label elapsed = Label("");
        private readonly Label resultSummary = Label("診断後、次に確認する手順をここへ表示します。");
        private readonly ListBox actions = new ListBox { Dock=DockStyle.Fill, IntegralHeight=false };
        private readonly TextBox actionDetail = ReadBox();
        private readonly ComboBox actionState = Combo("実施の記録なし","内容を確認","自分で試した","見送った");
        private readonly ComboBox outcome = Combo("再テスト: 未確認","再テスト: 改善した","再テスト: 変わらない","再テスト: 悪化した","再テスト: 判断できない");
        private readonly Button guide = Button("この手順のガイドを開く");
        private readonly Button official = Button("公式情報を開く");
        private readonly Button retest = Button("1つ試したら → 同じ場面を再テスト");
        private readonly TextBox report = ReadBox();
        private readonly Button export = Button("共有する内容を確認して保存");
        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer { Interval=1000 };

        internal MainForm()
        {
            Text="ゲムなお | PCゲーム診断 " + Rules.Version;
            Width=1100; Height=850; MinimumSize=new Size(800,650); StartPosition=FormStartPosition.CenterScreen;
            Font=new Font("Yu Gothic UI",10); AutoScaleMode=AutoScaleMode.Dpi;
            var root=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(14) };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize)); root.RowStyles.Add(new RowStyle(SizeType.Percent,100)); root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var header=Flow(); header.Controls.Add(new Label { Text="PCゲーム診断  症状から次の確認へ",Font=new Font(Font.FontFamily,18,FontStyle.Bold),AutoSize=true });
            header.Controls.Add(progress); root.Controls.Add(header,0,0); root.Controls.Add(tabs,0,1);
            root.Controls.Add(Label("PC設定変更・自動送信なし / 保存は本人操作 | 未署名 / Windows x64専用・新機能の実機確認前。保護機能が止めた場合は回避せず中止してください。"),0,2); Controls.Add(root);
            BuildSetup(); BuildMeasurement(); BuildActions(); BuildReportTab(); BuildHistoryTab();
            profile.SelectedIndexChanged+=(s,e)=>ChangeScope(); symptom.SelectedIndexChanged+=(s,e)=>ChangeScope(); store.SelectedIndexChanged+=(s,e)=>ChangeStore();
            consent.CheckedChanged+=(s,e)=>UpdateButtons();
            steamConsent.CheckedChanged+=(s,e)=>UpdateButtons(); chooseSteam.Click+=(s,e)=>ChooseSteamTarget();
            traceConsent.CheckedChanged+=(s,e)=>UpdateButtons(); archiveConsent.CheckedChanged+=(s,e)=>UpdateButtons();
            reread.Click+=async(s,e)=>await RefreshCapture(); rereadFromActions.Click+=async(s,e)=>await RefreshCapture(); pickArchive.Click+=async(s,e)=>await PickArchive();
            choose.Click+=(s,e)=>ChooseTarget(); find.Click+=async(s,e)=>await FindTarget(); reset.Click+=(s,e)=>ResetSession();
            begin.Click+=(s,e)=>BeginMeasurement(false); retest.Click+=(s,e)=>BeginMeasurement(true);
            recent.Click+=async(s,e)=>await ReadRecent(); finish.Click+=async(s,e)=>await FinishMeasurement();
            cancel.Click+=(s,e)=>CancelWork();
            foreach(var combo in new[]{stage,worked,demo,capture,mods,textures,pcIssue,verify,scene,frequency,lowerGraphics})combo.SelectedIndexChanged+=(s,e)=> { if(updating)return; RefreshResults(); UpdateButtons(); };
            actions.SelectedIndexChanged+=(s,e)=>ShowAction();
            actionState.SelectedIndexChanged+=(s,e)=> { if(updating || actions.SelectedIndex<0 || actions.SelectedIndex>=plan.Count)return; string id=plan[actions.SelectedIndex].Step.Id; StepState state=(StepState)actionState.SelectedIndex; states[id]=state; journal.Record(id,state,ActionOutcome.Unrecorded); RefreshResults(); RefreshJournal(); };
            outcome.SelectedIndexChanged+=(s,e)=> { if(updating)return; if(retestActionId!=null&&baseline!=null&&current!=null){journal.Record(retestActionId,StepState.Tried,ActionJournal.FromTrial((TrialOutcome)outcome.SelectedIndex),baseline,current);states[retestActionId]=StepState.Tried;RefreshJournal();} RefreshResults(outcome.SelectedIndex==2 || outcome.SelectedIndex==3); };
            guide.Click+=(s,e)=>OpenLink(false); official.Click+=(s,e)=>OpenLink(true); export.Click+=(s,e)=>ShowExport();
            timer.Tick+=(s,e)=> { if(measureStart.HasValue) { var span=DateTime.UtcNow-measureStart.Value; elapsed.Text="記録する範囲: "+span.ToString(@"hh\:mm\:ss"); if(span.TotalHours>=24) { measureStart=null; timer.Stop(); progress.Text="24時間を超えたため計測を中止しました。新しい短い範囲でやり直してください。"; UpdateButtons(); } } };
            FormClosing+=(s,e)=> { cancellation?.Cancel(); timer.Stop(); };
            FormClosed+=(s,e)=> { timer.Dispose(); cancellation?.Dispose(); };
            UpdateButtons();
        }
        private void BuildSetup()
        {
            var page=new TabPage("1  準備"); var f=Flow(); f.Dock=DockStyle.Fill; f.AutoScroll=true;
            f.Controls.Add(Label("ゲーム本体EXEと症状を選ぶ共通コースです。起動不可・クラッシュ・黒画面・フリーズ・低FPS・カクつきの確認を案内します。すべてのゲーム固有の原因を特定する機能ではありません。Wildsの経験は任意の固有ルールとして利用します。"));
            f.Controls.Add(Label("取得範囲: 選んだ本体EXEの版・互換性登録、OS・CPU・GPU/ドライバー・RAM・2ドライブ容量、指定範囲の1000/1002・4101/41記録（障害モジュール名/版/位置を含む）。共通コースはゲームフォルダや独自ログ/ZIPを走査しません。Wilds固有コースのときだけSteam登録検索/CrashReportフォルダのZIP有無・時刻が対象になります。\nセーブやSteamのユーザー別フォルダは読みません。追加確認を選んだ場合だけ、既知の痕跡やZIP内の指定項目を読みます。登録ファイルに識別情報が含まれる場合も、場所など同意範囲の固定項目だけを利用し、識別情報は保存/出力しません。フルディスク走査・アップロードはしません。"));
            f.Controls.Add(Row(Label("診断するルール"),profile)); f.Controls.Add(Row(Label("困っている症状"),symptom)); f.Controls.Add(Row(Label("ゲームの配布元"),store));
            f.Controls.Add(consent); f.Controls.Add(traceConsent); f.Controls.Add(archiveConsent); f.Controls.Add(steamConsent); f.Controls.Add(Label("Steam追加確認は固定6名だけ。Steamのモジュール一覧を一時取得し、既知名5件の場所分類だけ保持します。本文/プロセスのタイトル/引数/他アプリ一覧は記録しません。読み込み一覧以外の実行メモリは解析しません。権限不足は不明のままです。")); f.Controls.Add(Row(find,choose,reset)); f.Controls.Add(chooseSteam); f.Controls.Add(targetLabel);
            f.Controls.Add(Label("本体EXEの選び方: 配布元のローカルファイル表示で実際のゲーム本体を選びます。Steamならライブラリ → 対象ゲームを右クリック → 管理 → ローカルファイルを閲覧。ランチャー/クラッシュ報告用EXEとは別の場合があります。保護されたフォルダで選べない場合は、権限を変更せず中止してください。Wilds検索は固有ルール選択時だけ使えます。"));
            f.Controls.Add(Row(Label("発生する場面"),scene)); f.Controls.Add(Row(Label("発生する頻度"),frequency)); f.Controls.Add(Row(Label("画質を1項目下げた結果（性能症状用）"),lowerGraphics));
            f.Controls.Add(Row(Label("Wilds起動時の詳細（固有ルール用）"),stage)); f.Controls.Add(Row(Label("このゲームで以前遊べた？"),worked));
            f.Controls.Add(Row(Label("体験版/βで遊べた？"),demo)); f.Controls.Add(Row(Label("録画/オーバーレイ"),capture));
            f.Controls.Add(Row(Label("MOD/描画ツール"),mods)); f.Controls.Add(Row(Label("高解像度テクスチャDLC"),textures));
            f.Controls.Add(Row(Label("PC全体の状態"),pcIssue)); f.Controls.Add(Row(Label("配布元のファイル検証（本人記録）"),verify));
            f.Controls.Add(Label("分からない項目はそのままで構いません。まず1回だけ記録します。電源断・異常な発熱・PC全体の再起動があるなら再現せず、直近の記録だけを読んでください。"));
            f.Controls.Add(Row(begin,recent)); page.Controls.Add(f); tabs.TabPages.Add(page);
        }
        private void BuildMeasurement()
        {
            var page=new TabPage("2  症状を記録"); var f=Flow(); f.Dock=DockStyle.Fill; f.AutoScroll=true;
            f.Controls.Add(new Label { Text="いつもと同じ場面で、症状を1回確認",AutoSize=true,Font=new Font(Font.FontFamily,16,FontStyle.Bold) });
            f.Controls.Add(measureLabel); f.Controls.Add(elapsed);
            f.Controls.Add(Label("このツールはゲームの操作・画面録画・FPSや温度の計測をしません。開始〜終了の時刻だけを保持し、下のボタンの後に該当するWindowsの記録を読みます。\nクラッシュ表示が出ても、CrashReport生成中はまだ押さずに待ってください。起動できた場合/性能症状では同じ短い場面を確認し、安全にゲームを終了してから進めます。"));
            f.Controls.Add(Label("先にCrashReportの「生成完了」を確認 → その後に下の読み取りボタン。生成画面が出ない場合は終了後に進めます。数分の生成待ちはゲームのフリーズとは別です。"));
            f.Controls.Add(Row(finish,cancel));
            f.Controls.Add(Label("終了後はログの書き込みを5秒待ってから読み取ります。それでも記録が遅れたり残らないことがあります。記録がないことを『正常』とは判断しません。\n待ち時間が長い場合は中止またはこのアプリを閉じられます。Windows APIの待機は即時終了できない場合があります。"));
            page.Controls.Add(f); tabs.TabPages.Add(page);
        }
        private void BuildActions()
        {
            var page=new TabPage("3  次の一手");
            var grid=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=6,Padding=new Padding(8) };
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize)); grid.RowStyles.Add(new RowStyle(SizeType.AutoSize)); grid.RowStyles.Add(new RowStyle(SizeType.Absolute,145)); grid.RowStyles.Add(new RowStyle(SizeType.Percent,100)); grid.RowStyles.Add(new RowStyle(SizeType.AutoSize)); grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            grid.Controls.Add(resultSummary,0,0); grid.Controls.Add(Row(rereadFromActions),0,1); grid.Controls.Add(actions,0,2); grid.Controls.Add(actionDetail,0,3); grid.Controls.Add(Row(actionState,guide,official),0,4); grid.Controls.Add(Row(retest,outcome),0,5);
            page.Controls.Add(grid); tabs.TabPages.Add(page);
        }
        private void BuildReportTab()
        {
            var page=new TabPage("4  詳細と保存"); var grid=new TableLayoutPanel { Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Padding=new Padding(8) };
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize)); grid.RowStyles.Add(new RowStyle(SizeType.Percent,100)); grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            grid.Controls.Add(Label("この画面の冒頭にはローカル表示だけのCPU/GPU名があります。保存時は除外します。共有前に別画面で実際に保存する全文を確認できます。"),0,0); grid.Controls.Add(report,0,1); grid.Controls.Add(Row(export,reread,pickArchive),0,2); page.Controls.Add(grid); tabs.TabPages.Add(page);
        }
        private static Button Button(string t) { return new Button { Text=t,AutoSize=true,Padding=new Padding(8,4,8,4),Margin=new Padding(3,5,3,5) }; }
        private static Label Label(string t) { return new Label { Text=t,AutoSize=true,MaximumSize=new Size(950,0),Margin=new Padding(3,7,3,7) }; }
        private static ComboBox Combo(params string[] items) { var c=new ComboBox { DropDownStyle=ComboBoxStyle.DropDownList,Width=330 }; c.Items.AddRange(items); c.SelectedIndex=0; return c; }
        private static TextBox ReadBox() { return new TextBox { Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=true,Dock=DockStyle.Fill,BackColor=Color.White }; }
        private static FlowLayoutPanel Flow() { return new FlowLayoutPanel { FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,Padding=new Padding(8) }; }
        private static FlowLayoutPanel Row(params Control[] controls) { var f=new FlowLayoutPanel { AutoSize=true,WrapContents=true,MaximumSize=new Size(970,0) }; f.Controls.AddRange(controls); return f; }
        private WildsAnswers Answers() { return new WildsAnswers { Stage=(LaunchStage)stage.SelectedIndex,WorkedBefore=(Answer)worked.SelectedIndex,DemoWorked=(Answer)demo.SelectedIndex,CaptureTools=(Answer)capture.SelectedIndex,Mods=(Answer)mods.SelectedIndex,TexturePack=(Answer)textures.SelectedIndex,WholePcIssue=(Answer)pcIssue.SelectedIndex,Verification=(VerifyResult)verify.SelectedIndex }; }
        private GameAnswers GeneralAnswers(){return new GameAnswers{Symptom=selectedSymptom,Store=(GameStore)store.SelectedIndex,Scene=(GameScene)scene.SelectedIndex,Frequency=(Frequency)frequency.SelectedIndex,LowerGraphics=(GraphicsTrial)lowerGraphics.SelectedIndex,Shared=Answers()};}
        private void BindJournal(){if(targetPath!=null&&!journal.Bound)journal.Bind(targetPath,selectedGame,selectedSymptom);}
        private void ClearGameAnswers()
        {
            foreach(var c in new[]{stage,worked,demo,capture,mods,textures,verify,scene,frequency,lowerGraphics})c.SelectedIndex=0;
        }
        private void ChangeStore()
        {
            if(updating)return;
            var next=(GameStore)store.SelectedIndex;
            if(selectedGame==GameKind.Wilds&&next!=GameStore.Steam){updating=true;store.SelectedIndex=(int)selectedStore;updating=false;MessageBox.Show(this,"Wilds固有ルールはSteam版用です。他の配布元ならPCゲーム共通を選んでください。");return;}
            if(current!=null&&MessageBox.Show(this,"配布元を変えるため取得済みの比較をクリアします。本人の実施履歴は保持します。変更しますか？","配布元変更",MessageBoxButtons.YesNo)!=DialogResult.Yes){updating=true;store.SelectedIndex=(int)selectedStore;updating=false;return;}
            selectedStore=next;updating=true;steamConsent.Checked=false;steamExe=null;updating=false;
            current=baseline=null;targetSession=Guid.NewGuid();retestActionId=pendingRetestActionId=null;plan.Clear();actions.Items.Clear();actionDetail.Clear();report.Clear();resultSummary.Text="配布元を変更しました。新しい読み取り待ちです。";UpdateButtons();
        }
        private void ChangeScope()
        {
            if(updating)return;
            var nextGame=(GameKind)profile.SelectedIndex;var nextSymptom=(GameSymptom)symptom.SelectedIndex;
            if(nextGame==selectedGame&&nextSymptom==selectedSymptom)return;
            if((current!=null||journal.Records.Count>0)&&MessageBox.Show(this,"ルール/症状を変えると、別の診断として画面内の記録・比較をクリアします。必要なら先に履歴を保存してください。変更しますか？","診断の区分変更",MessageBoxButtons.YesNo)!=DialogResult.Yes)
            {updating=true;profile.SelectedIndex=(int)selectedGame;symptom.SelectedIndex=(int)selectedSymptom;updating=false;return;}
            selectedGame=nextGame;selectedSymptom=nextSymptom;
            if(targetPath!=null&&!GameProfile.Accepts(targetPath,selectedGame)){targetPath=null;steamExe=null;targetLabel.Text="ゲーム未選択。固有ルールに合う本体を選んでください。";}
            updating=true;ClearGameAnswers();if(selectedGame==GameKind.Wilds){store.SelectedIndex=(int)GameStore.Steam;selectedStore=GameStore.Steam;}updating=false;
            current=baseline=null;targetSession=Guid.NewGuid();journal=new ActionJournal();BindJournal();states.Clear();plan.Clear();actions.Items.Clear();actionDetail.Clear();report.Clear();retestActionId=pendingRetestActionId=null;
            updating=true;outcome.SelectedIndex=0;traceConsent.Checked=archiveConsent.Checked=false;updating=false;
            ResetHistoryCatalog();RefreshJournal();progress.Text="診断の区分を変更しました。新しい取得待ちです。";resultSummary.Text="最初の記録待ち";UpdateButtons();
        }
        private void SelectTarget(string path,string steam)
        {
            if(!GameProfile.Accepts(path,selectedGame) || !LocalGuard.Allowed(path)) { MessageBox.Show(this,"ローカル固定ドライブのゲーム本体EXEを選んでください。Wilds固有ルールはMonsterHunterWilds.exeのみです。ネットワーク/リンク/保護されたアプリ経由はこの版の対象外です。"); return; }
            if(string.Equals(path,targetPath,StringComparison.OrdinalIgnoreCase))
            {
                if(!string.IsNullOrEmpty(steam))
                {
                    string next=Path.GetFullPath(steam);
                    if(!string.Equals(next,steamExe,StringComparison.OrdinalIgnoreCase))
                    {
                        if(current!=null&&MessageBox.Show(this,"ゲームは同じですがSteam本体の関連付けが変わります。取得済みの比較をクリアし、本人の手順履歴を保持して続けますか？","Steamの関連付け",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;
                        steamExe=next;current=baseline=null;targetSession=Guid.NewGuid();retestActionId=pendingRetestActionId=null;report.Clear();plan.Clear();actions.Items.Clear();actionDetail.Clear();resultSummary.Text="Steamの関連付けを更新しました。新しい読み取り待ちです。";
                    }
                    progress.Text="同じ本体を確認しました。次の読み取りでSteam側の互換モード登録も確認できます。";UpdateButtons();
                }
                return;
            }
            if(targetPath!=null&&journal.Records.Count>0&&MessageBox.Show(this,"別のゲーム導入先に変更すると、画面内の比較と手順記録を新しい診断にします。必要なら先に履歴を保存してください。変更しますか？","対象変更",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;
            updating=true;
            if(targetPath!=null){ClearGameAnswers();steamConsent.Checked=false;store.SelectedIndex=(int)(selectedGame==GameKind.Wilds?GameStore.Steam:GameStore.Unknown);selectedStore=(GameStore)store.SelectedIndex;}
            journal=new ActionJournal(); retestActionId=pendingRetestActionId=null;updating=false;
            targetPath=Path.GetFullPath(path); steamExe=steam==null?null:Path.GetFullPath(steam); targetSession=Guid.NewGuid(); current=baseline=null; states.Clear(); plan.Clear(); actions.Items.Clear(); outcome.SelectedIndex=0;
            BindJournal();
            targetLabel.Text="ゲーム本体を選択済み（このPC内のみ）: "+Rules.LocalLabel(path);
            progress.Text="準備できました。起動直前の開始、または直近10分の読み取りを選びます。"; report.Clear(); actionDetail.Clear(); resultSummary.Text="最初の記録待ち"; RefreshJournal(); UpdateButtons();
        }
        private void ChooseTarget()
        {
            if(!consent.Checked || busy || measureStart.HasValue)return;
            using(var d=new OpenFileDialog { Title="実際に症状が出るゲーム本体EXEを選ぶ（実行しません）",Filter="ゲーム本体 (*.exe)|*.exe",FileName="",CheckFileExists=true,Multiselect=false,RestoreDirectory=true }) if(d.ShowDialog(this)==DialogResult.OK)SelectTarget(d.FileName,null);
        }
        private void ChooseSteamTarget()
        {
            if(!consent.Checked||!steamConsent.Checked||busy||measureStart.HasValue)return;
            using(var dialog=new OpenFileDialog{Title="実際に使用するSteam本体の steam.exe を選ぶ（実行しません）",Filter="Steam本体|steam.exe",FileName="steam.exe",CheckFileExists=true,Multiselect=false,RestoreDirectory=true})
            {
                if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                if(!LocalGuard.Allowed(dialog.FileName)||!string.Equals(Rules.FileName(dialog.FileName),"steam.exe",StringComparison.OrdinalIgnoreCase)){MessageBox.Show(this,"ローカル固定ドライブのSteam本体を選んでください。");return;}
                string next=Path.GetFullPath(dialog.FileName);if(string.Equals(next,steamExe,StringComparison.OrdinalIgnoreCase))return;
                if(current!=null&&MessageBox.Show(this,"Steamの選択が変わるので取得済み比較をクリアします。本人が記録した手順履歴は保持します。よいですか？","Steamの選択",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;
                steamExe=next;current=baseline=null;targetSession=Guid.NewGuid();retestActionId=pendingRetestActionId=null;report.Clear();plan.Clear();actions.Items.Clear();actionDetail.Clear();resultSummary.Text="Steam本体を選択しました。次の読み取りで実行中の本体パスと照合します。";progress.Text="Steam本体を選択済み（ローカルのみ）。名前が同じ別の本体は照合に含めません。";UpdateButtons();
            }
        }
        private async Task FindTarget()
        {
            if(!consent.Checked || selectedGame!=GameKind.Wilds || busy || measureStart.HasValue)return;
            busy=true; cancellation?.Dispose(); cancellation=new CancellationTokenSource(); UpdateButtons(); progress.Text="Steamの登録場所と、登録されたローカルライブラリだけを確認しています。";
            try
            {
                var token=cancellation.Token;
                var found=await Task.Run(()=>SteamDiscovery.Find(token)); if(IsDisposed)return; token.ThrowIfCancellationRequested();
                if(found.Entries.Count==1)SelectTarget(found.Entries[0].GamePath,found.Entries[0].SteamExe);
                else if(found.Entries.Count>1)
                {
                    using(var dlg=new Form { Text="使っているワイルズの場所を選択（ローカル表示のみ）",Width=800,Height=300,StartPosition=FormStartPosition.CenterParent })
                    {
                        var list=new ListBox { Dock=DockStyle.Fill }; list.Items.AddRange(found.Entries.Select(x=>(object)x.GamePath).ToArray()); list.SelectedIndex=0;
                        var ok=Button("この場所を選ぶ"); ok.Dock=DockStyle.Bottom; ok.Click+=(s,e)=>dlg.DialogResult=DialogResult.OK; dlg.Controls.Add(list); dlg.Controls.Add(ok);
                        if(dlg.ShowDialog(this)==DialogResult.OK) { var item=found.Entries[list.SelectedIndex]; SelectTarget(item.GamePath,item.SteamExe); }
                    }
                }
                else progress.Text="登録先から見つかりませんでした。未インストールとは限りません。「自分で本体EXEを選ぶ」を使ってください。";
                if(found.Incomplete && targetPath!=null)progress.Text="本体を選択しました。一部の登録情報は取得できませんでした。実際に使っている場所か確認してください。";
            }
            catch(OperationCanceledException) { if(!IsDisposed)progress.Text="検索を中止しました。前の選択を保持しています。"; }
            catch { if(!IsDisposed)progress.Text="自動検索を完了できませんでした。手動選択を使えます。"; }
            finally { busy=false; if(!IsDisposed)UpdateButtons(); }
        }
        private void ResetSession()
        {
            if(busy || measureStart.HasValue)return;
            if((current!=null||journal.Records.Count>0) && MessageBox.Show(this,"未保存の結果と手順記録を消して、新しい診断にしますか？","新しい診断",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;
            journal=new ActionJournal();BindJournal();sessionRestartObserved=false;retestActionId=pendingRetestActionId=null;current=baseline=null; targetSession=Guid.NewGuid(); states.Clear(); plan.Clear(); actions.Items.Clear(); actionDetail.Clear(); report.Clear(); outcome.SelectedIndex=0; progress.Text="新しい診断です。ゲームの選択は維持しています。"; resultSummary.Text="最初の記録待ち"; tabs.SelectedIndex=0; RefreshJournal(); UpdateButtons();
        }
        private void BeginMeasurement(bool repeat)
        {
            if(busy || measureStart.HasValue || !consent.Checked || targetPath==null)return;
            if(sessionRestartObserved||!WildsProfile.MayRetest(current,Answers())) { MessageBox.Show(this,"PC全体の異常の申告/記録があります。再現を止め、直近の記録や公式相談を優先してください。"); return; }
            repeat = repeat || current != null;
            if(MessageBox.Show(this,"PC全体の電源断・異常な発熱・再起動がない場合だけ、同じ症状の場面を短く1回だけ確認してください。\nこのツールはゲームを起動/操作しません。"+(repeat?"\n比較のため、試す対処は1つだけにしてください。":"")+"\n\n安全に試せるので、記録範囲の計測を開始しますか？","起動の記録",MessageBoxButtons.YesNo,MessageBoxIcon.Information,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            measurementIsRetest=repeat;
            pendingRetestActionId=repeat&&actions.SelectedIndex>=0&&actions.SelectedIndex<plan.Count?plan[actions.SelectedIndex].Step.Id:null;
            measureStart=DateTime.UtcNow; timer.Start(); elapsed.Text="記録する範囲: 00:00:00"; tabs.SelectedIndex=1;
            measureLabel.Text="普段の配布元からゲームを起動し、同じ症状の場面を1回確認してください。性能の値はゲーム内表示等で本人が確認します。落ちてレポート生成中なら完了を待ちます。";
            progress.Text=repeat?"再テストを計測中。直前の記録と比較します。":"最初の起動を計測中。まだWindowsログは読み取っていません。"; UpdateButtons();
        }
        private async Task FinishMeasurement()
        {
            if(!measureStart.HasValue || busy)return;
            DateTime start=measureStart.Value;
            if((DateTime.UtcNow-start).TotalSeconds<3) { MessageBox.Show(this,"実際に症状の場面を確認してから押してください。自動では起動していません。"); return; }
            if(MessageBox.Show(this,"CrashReportの生成画面が出た場合は、生成完了まで待ってください。クラッシュ表示直後は記録がまだ残っていないことがあります。\n\n生成完了を確認した、または生成画面は出ていませんか？\n『いいえ』で計測を続けます。ゲームを起動し直す必要はありません。","読み取る前の確認",MessageBoxButtons.YesNo,MessageBoxIcon.Information,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            timer.Stop(); measureStart=null;
            await Collect(start,DateTime.UtcNow,true,measurementIsRetest?CaptureMode.Retest:CaptureMode.InitialAttempt);
        }
        private async Task ReadRecent()
        {
            if(busy || measureStart.HasValue || !consent.Checked || targetPath==null)return;
            if(current!=null) { await RefreshCapture(); return; }
            DateTime end=DateTime.UtcNow; await Collect(end.AddMinutes(-10),end,false,CaptureMode.InitialRecent);
        }
        private async Task Collect(DateTime start,DateTime end,bool settle,CaptureMode mode)
        {
            busy=true; cancellation?.Dispose(); cancellation=new CancellationTokenSource(); UpdateButtons(); tabs.SelectedIndex=1;
            try
            {
                var token=cancellation.Token;
                if(settle) { progress.Text="ログの書き込みを5秒待っています。ゲームの再起動は不要です。"; await Task.Delay(5000,token); end=DateTime.UtcNow; }
                progress.Text="Windowsの選別済み記録とPC状態を読み取り中。設定は変更しません。";
                bool wilds=selectedGame==GameKind.Wilds;
                bool readTraces=wilds&&traceConsent.Checked,readArchive=wilds&&archiveConsent.Checked,readSteam=store.SelectedIndex==(int)GameStore.Steam&&steamConsent.Checked;
                GameKind kind=selectedGame;GameSymptom issue=selectedSymptom;string steam=store.SelectedIndex==(int)GameStore.Steam?steamExe:null;
                var s=await Task.Run(()=>WindowsCollector.Collect(targetPath,targetSession,start,end,token,steam,readTraces,readArchive,readSteam,kind,issue));
                if(IsDisposed)return;
                if(!WildsProfile.AcceptsCapture(s,targetSession,token.IsCancellationRequested))throw new OperationCanceledException();
                s.PriorRestartObserved|=sessionRestartObserved;
                CaptureTransition committed;
                if(!CaptureWorkflow.TryCommit(s,current,baseline,targetSession,token.IsCancellationRequested,mode,(TrialOutcome)outcome.SelectedIndex,out committed))
                    throw new InvalidOperationException("Capture transition rejected.");
                baseline=committed.Baseline;
                if(!committed.PreserveStepRecords&&journal.Records.Count==0)states.Clear();
                if(mode!=CaptureMode.Refresh)retestActionId=mode==CaptureMode.Retest?pendingRetestActionId:null;
                current=committed.Current;sessionRestartObserved|=current.PriorRestartObserved||current.System.Events.Any(e=>e.Kind==EventKind.UncleanRestart); updating=true; outcome.SelectedIndex=(int)committed.Outcome; updating=false; RefreshResults(); tabs.SelectedIndex=2;
                progress.Text=mode==CaptureMode.Refresh?"同じ記録を読み直しました。比較元・手順状態・本人の結果を保持しています。新しい再テストには数えません。":current.Application.Events.Count==0?"取得は終わりましたが、アプリ記録は0件です。生成完了待ちと読み直しの案内を確認してください。":"読み取り終了。事実と候補を確認します。以前に試した操作は繰り返さず、手順状態に記録してください。";
            }
            catch(OperationCanceledException) { if(!IsDisposed)progress.Text="中止しました。前の取得済み記録があれば保持しています。"; }
            catch { if(!IsDisposed)progress.Text="読み取りを完了できませんでした。前の結果を保持。手順1へ戻って対象を確認してください。"; }
            finally { busy=false; if(!IsDisposed)UpdateButtons(); }
        }
        private async Task RefreshCapture()
        {
            if(current==null||busy||measureStart.HasValue||!consent.Checked)return;
            DateTime end=DateTime.UtcNow;
            if(!CaptureWorkflow.CanRefresh(current,end)){MessageBox.Show(this,"同じ記録の読み直しは、元の開始から30分以内です。結果と手順状態は保持しています。保存や、完了済みのCrashReport ZIPの手動選択は可能です。別の時間範囲が必要なら保存後に『新しい診断を始める』を選んでください。ゲームの再起動は不要です。");return;}
            if(MessageBox.Show(this,"CrashReport生成中なら、完了してから読み直してください。\nゲームを追加で起動せず、開始時刻を維持したまま終了を現在まで延ばします（開始から最大30分）。比較元・手順状態・本人の結果は保持します。別の起動や設定変更が入った場合は、いいえを選んでください。\n\n生成完了後、追加の起動や設定変更をせずに読み直しますか？","遅延した記録の確認",MessageBoxButtons.YesNo,MessageBoxIcon.Information,MessageBoxDefaultButton.Button2)!=DialogResult.Yes)return;
            end=DateTime.UtcNow;
            if(!CaptureWorkflow.CanRefresh(current,end)){MessageBox.Show(this,"確認中に読み直せる範囲を超えたため、追加の読み取りは行いません。結果と手順状態を保持しています。");return;}
            await Collect(current.StartUtc,end,false,CaptureMode.Refresh);
        }
        private async Task PickArchive()
        {
            if(current==null||current.Game!=GameKind.Wilds||selectedGame!=GameKind.Wilds||busy||!consent.Checked||!archiveConsent.Checked)return;
            using(var dialog=new OpenFileDialog{Title="読むCrashReport ZIPを1個選択（生データは保存/送信しません）",Filter="ZIP (*.zip)|*.zip",CheckFileExists=true,Multiselect=false,RestoreDirectory=true})
            {
                if(dialog.ShowDialog(this)!=DialogResult.OK)return;
                busy=true;cancellation?.Dispose();cancellation=new CancellationTokenSource();var token=cancellation.Token;UpdateButtons();
                string archivePath=dialog.FileName;var moduleContext=steamConsent.Checked?SteamLocal.Context(steamExe):null;
                try{var facts=await Task.Run(()=>OptionalChecks.ReadArchive(archivePath,token,moduleContext));if(IsDisposed)return;token.ThrowIfCancellationRequested();current.Archive=facts;RefreshResults();tabs.SelectedIndex=3;}
                catch(OperationCanceledException){if(!IsDisposed)progress.Text="ZIP読取りを中止し、前の結果を保持しました。";}
                catch{if(!IsDisposed)progress.Text="ZIPを読めませんでした。前の結果を保持しています。";}
                finally{busy=false;if(!IsDisposed)UpdateButtons();}
            }
        }
        private void CancelWork()
        {
            if(measureStart.HasValue) { measureStart=null; timer.Stop(); progress.Text="計測を中止しました。Windowsログは読み取っていません。"; UpdateButtons(); }
            else if(busy) { cancellation?.Cancel(); progress.Text="中止を要求しました。Windows APIの待機が戻るまで時間がかかる場合があります。閉じても構いません。"; cancel.Enabled=false; }
        }
        private void RefreshResults(bool advance=false)
        {
            if(current==null)return;
            string previous=actions.SelectedIndex>=0 && actions.SelectedIndex<plan.Count?plan[actions.SelectedIndex].Step.Id:null;
            plan=GameProfile.Plan(current,GeneralAnswers()); updating=true; actions.Items.Clear();
            foreach(var item in plan) { StepState st; if(!states.TryGetValue(item.Step.Id,out st))st=StepState.NotStarted; actions.Items.Add("["+Rules.StateText(st)+"] "+item.Step.Title); }
            int next=WildsProfile.NextUntried(plan,states);
            int index=advance?next:plan.FindIndex(x=>x.Step.Id==previous);
            if(index<0)index=next;
            if(index<0)index=Math.Max(0,plan.FindIndex(x=>x.Step.Id=="wilds-records"||x.Step.Id=="game-records")); if(actions.Items.Count>0)actions.SelectedIndex=index; updating=false; ShowAction();
            int count=current.Application.Events.Count;
            resultSummary.Text="記録から原因はまだ確定していません。選択したゲームに対応するアプリ記録: "+count+"件（パス完全一致 "+current.Application.Events.Count(x=>x.Match==MatchKind.ExactPath)+"、名前のみ "+current.Application.Events.Count(x=>x.Match==MatchKind.NameOnly)+"） / "+Rules.StatusText(current.Application.Status)+"\n"+(count==0?(GameProfile.IsPerformance(selectedSymptom)?"性能の症状はエラーログが残らない場合があります。FPS未計測のため、この件数で性能を判定しません。":CaptureWorkflow.MissingRecordHint):"障害モジュールや例外は手掛かりです。故障部品を断定しません。");
            resultSummary.Text+="\n手順の状態は本人の記録です。実施の記録なし＝まだ試していない、とは限りません。";
            if(next<0)resultSummary.Text+="\n未実施の確認が残っていません。同じ手順を繰り返さず、レポートを保管して公式窓口へ相談できます。";
            if(journal.Records.Any(r=>r.Outcome==ActionOutcome.Resolved))resultSummary.Text+="\n履歴に解決したとの本人の記録があります。現在も遊べるなら追加の変更や失敗の再現は不要です。";
            if(outcome.SelectedIndex==1)resultSummary.Text+="\n今回は改善したとの本人の記録です。追加変更を止め、この条件を保って確認してください。完全解決の断定ではありません。";
            RefreshReport(); UpdateButtons();
        }
        private void ShowAction()
        {
            int i=actions.SelectedIndex; if(i<0 || i>=plan.Count)return;
            var item=plan[i];
            string nextText=(item.Step.Id=="wilds-stop"||item.Step.Id=="stop")?"再現を行わず、記録を保管してメーカー等へ相談してください。":(item.Step.Id=="wilds-records"||item.Step.Id=="game-records")?"相談用の内容を保存し、必要なものだけを本人が公式窓口へ渡してください。":"実行後: 状態を『自分で試した』にし、再テストへ。改善しなければ次の手順を選びます。";
            actionDetail.Text=ForTextBox(item.Step.Title+"\n\nなぜ候補？\n"+item.Reason+"\n\n自分で行う手順\n"+item.Step.Instructions+"\n\n注意・戻し方\n"+item.Step.Warning+"\n\n"+nextText+"\n\n公式情報: "+item.Step.OfficialUrl);
            StepState st; if(!states.TryGetValue(item.Step.Id,out st))st=StepState.NotStarted; updating=true; actionState.SelectedIndex=(int)st; updating=false;
        }
        private string ExportText(bool knownNames=false)
        {
            return GameProfile.Summary(current,GeneralAnswers(),states)+(current.Game==GameKind.Wilds?TraceEvidence.Summary(current,Answers())+CrashArchive.Summary(current.Archive,current,knownNames):"\n一般ゲームの独自ログ/ZIP/ダンプは解析していません。\n")+SteamEvidence.Summary(current.Steam)+journal.Summary()+"\n"+Rules.BuildReport(current,baseline,(TrialOutcome)outcome.SelectedIndex,states,false,knownNames);
        }
        private void RefreshReport()
        {
            if(current==null)return;
            report.Text=ForTextBox("【この画面のみ。保存レポートでは除外】\nCPU: "+current.Hardware.LocalCpuName+"\nGPU: "+string.Join(" / ",current.Hardware.LocalGpuNames)+"\n\n"+CrashDetails.LocalDetails(current)+"\n"+ExportText());
        }
        private void UpdateButtons()
        {
            bool idle=!busy && !measureStart.HasValue;
            consent.Enabled=profile.Enabled=symptom.Enabled=store.Enabled=idle;traceConsent.Enabled=archiveConsent.Enabled=idle&&selectedGame==GameKind.Wilds;steamConsent.Enabled=idle&&store.SelectedIndex==(int)GameStore.Steam; chooseSteam.Enabled=idle&&consent.Checked&&steamConsent.Checked&&steamConsent.Enabled; find.Enabled=idle&&consent.Checked&&selectedGame==GameKind.Wilds;choose.Enabled=idle&&consent.Checked; reset.Enabled=idle;
            recent.Enabled=idle && consent.Checked && targetPath!=null;
            recent.Text=current==null?"すでに症状が出た場合: 直近10分を読む":CaptureWorkflow.RefreshButtonText;
            begin.Enabled=recent.Enabled && !sessionRestartObserved && WildsProfile.MayRetest(current,Answers());
            begin.Text=current==null?"症状を確認する直前 → 記録開始":"記録あり → 同じ場面を再テスト";
            finish.Enabled=!busy && measureStart.HasValue; cancel.Enabled=busy || measureStart.HasValue;
            retest.Enabled=idle && consent.Checked && current!=null && !sessionRestartObserved && WildsProfile.MayRetest(current,Answers()); export.Enabled=idle && current!=null; reread.Enabled=rereadFromActions.Enabled=idle&&consent.Checked&&current!=null;pickArchive.Enabled=idle&&consent.Checked&&archiveConsent.Checked&&current!=null&&current.Game==GameKind.Wilds&&selectedGame==GameKind.Wilds;
            foreach(var c in new[]{stage,worked,demo,capture,mods,textures,pcIssue,verify,scene,frequency,lowerGraphics})c.Enabled=idle;
            stage.Enabled=textures.Enabled=idle&&GameProfile.UsesWildsRules(selectedGame,selectedSymptom);lowerGraphics.Enabled=idle&&GameProfile.IsPerformance(selectedSymptom);
            actions.Enabled=actionState.Enabled=outcome.Enabled=idle && current!=null;
            guide.Enabled=official.Enabled=idle && actions.SelectedIndex>=0; UpdateHistoryButtons();
        }
        private void OpenLink(bool officialLink)
        {
            if(actions.SelectedIndex<0 || actions.SelectedIndex>=plan.Count)return;
            var step=plan[actions.SelectedIndex].Step; string url=officialLink?step.OfficialUrl:step.GuideUrl;
            if(MessageBox.Show(this,"既定のブラウザーで公開ページを開きます。診断結果はURLに含めません。通常のWeb通信が発生します。\n\n"+url,"外部ページ",MessageBoxButtons.YesNo)!=DialogResult.Yes)return;
            try { Process.Start(new ProcessStartInfo(url){UseShellExecute=true}); } catch { MessageBox.Show(this,"ブラウザーを開けませんでした。レポートのURLを確認してください。"); }
        }
        private static string ForTextBox(string t) { return t.Replace("\r\n","\n").Replace("\n","\r\n"); }
        private void ShowExport()
        {
            if(current==null)return; string text=ExportText();
            using(var form=new Form { Text="この内容だけを保存します",Width=950,Height=700,StartPosition=FormStartPosition.CenterParent,Font=Font })
            {
                var box=ReadBox(); box.Text=ForTextBox(text);
                var bottom=Flow(); bottom.Dock=DockStyle.Bottom;
                bottom.Controls.Add(Label("選別済みですが完全匿名ではありません。対象名/パス、CPU/GPU名、生ログは除外しています。\n同期フォルダへ保存するとOneDrive等が同期する場合があります。内容を読んでから保存してください。"));
                var known=new CheckBox { Text="公開名の固定リストにあるDLL名も保存する（未知の名前/パスは保存しません）",AutoSize=true };
                var confirm=new CheckBox { Text="保存される全文を確認しました",AutoSize=true }; var save=Button("ローカルにテキスト保存"); save.Enabled=false; confirm.CheckedChanged+=(s,e)=>save.Enabled=confirm.Checked;
                known.CheckedChanged+=(s,e)=>{text=ExportText(known.Checked);box.Text=ForTextBox(text);confirm.Checked=false;};
                save.Click+=(s,e)=> {
                    using(var d=new SaveFileDialog { Filter="テキスト (*.txt)|*.txt",FileName="gemnao-game-diagnosis.txt",InitialDirectory=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),OverwritePrompt=true,AddExtension=true,RestoreDirectory=true })
                    {
                        if(d.ShowDialog(form)!=DialogResult.OK)return;
                        try { if(!LocalGuard.Allowed(d.FileName,true)) { MessageBox.Show(form,"リンク/ネットワーク経由でないローカル固定ドライブを選んでください。"); return; } File.WriteAllText(d.FileName,text,new UTF8Encoding(true)); MessageBox.Show(form,"確認した内容を保存しました。このアプリから外部送信していません。"); form.Close(); }
                        catch { MessageBox.Show(form,"保存できませんでした。別のローカル保存先を選んでください。"); }
                    }
                };
                bottom.Controls.Add(known); bottom.Controls.Add(confirm); bottom.Controls.Add(save); form.Controls.Add(box); form.Controls.Add(bottom); form.ShowDialog(this);
            }
        }
    }
}
