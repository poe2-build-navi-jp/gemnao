using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace Gemnao.Diagnostics
{
    public enum ReadStatus { NotRead, Complete, AccessDenied, Unavailable, TimedOut, Partial, Cancelled }
    public enum EventKind { ApplicationCrash, ApplicationHang, DisplayRecovery, UncleanRestart }
    public enum MatchKind { ExactPath, NameOnly, SystemContext }
    public enum ModuleKind { Unknown, WindowsCore, Graphics, VisualCpp, Other, TargetExecutable, SteamOverlay }
    public enum ParseOutcome { Accepted, NotTarget, Unsupported, Malformed }
    public enum TrialOutcome { NotTested, Better, Same, Worse, Unsure }
    public enum StepState { NotStarted, Checked, Tried, Skipped }

    public sealed class EventFact
    {
        public EventKind Kind;
        public MatchKind Match;
        public ModuleKind Module;
        public DateTime TimeUtc;
        public string LocalModuleName = "";
        public bool ModuleNameUnavailable;
        internal string ModuleIdentityToken = "";
        public MatchKind ModuleTargetMatch = MatchKind.NameOnly;
        public int[] AppVersionParts = new int[0];
        public int[] ModuleVersionParts = new int[0];
        public ulong? FaultOffset;
        public string ExceptionCode = ""; // Exactly eight hex digits, never free text.
    }
    public sealed class LogFacts
    {
        public ReadStatus Status = ReadStatus.NotRead;
        public int Examined;
        public int Unsupported;
        public bool LimitReached;
        public readonly List<EventFact> Events = new List<EventFact>();
    }
    public sealed class GpuFact
    {
        public string Vendor = "不明";
        public string DriverVersion = "不明";
    }
    public sealed class DiskFact
    {
        public bool IsSystem;
        public long? FreeMiB;
        public long? TotalMiB;
    }
    public sealed class HardwareFacts
    {
        public ReadStatus OsStatus = ReadStatus.NotRead;
        public ReadStatus CpuStatus = ReadStatus.NotRead;
        public ReadStatus GpuStatus = ReadStatus.NotRead;
        public ReadStatus DiskStatus = ReadStatus.NotRead;
        public string OsVersion = "不明";
        public string CpuVendor = "不明";
        public int? LogicalProcessors;
        public long? TotalMemoryMiB;
        public long? FreeMemoryMiB;
        public readonly List<GpuFact> Gpus = new List<GpuFact>();
        public readonly List<DiskFact> Disks = new List<DiskFact>();
        // Display-only, never passed to the export formatter.
        public string LocalCpuName = "不明";
        public readonly List<string> LocalGpuNames = new List<string>();
    }
    public sealed class Snapshot
    {
        public GameKind Game;
        public GameSymptom Symptom;
        public DateTime StartUtc;
        public DateTime EndUtc;
        public DateTime CollectedUtc;
        // Session-local opaque identity prevents accidental cross-target comparisons; never exported.
        public Guid TargetSession;
        internal Guid AttemptId;
        public CaptureOrigin Origin;
        public int RefreshCount;
        public bool PriorRestartObserved;
        public CrashArchiveFacts Archive = new CrashArchiveFacts();
        public readonly SteamFacts Steam = new SteamFacts();
        public readonly WildsFacts Wilds = new WildsFacts();
        public readonly HardwareFacts Hardware = new HardwareFacts();
        public readonly LogFacts Application = new LogFacts();
        public readonly LogFacts System = new LogFacts();
    }
    public sealed class Finding
    {
        public string Evidence;
        public string Candidate;
        public string Unknown;
        public string StepId;
    }
    public sealed class GuideStep
    {
        public string Id;
        public string Title;
        public string Instructions;
        public string Warning;
        public string GuideUrl;
        public string OfficialUrl;
    }
    public static class Rules
    {
        public const string Version = "0.5.0";
        public const int MaxEventsPerLog = 300;
        public const int MaxWindowHours = 24;
        public static string NumericVersion(object value)
        {
            string s = Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
            if (!Regex.IsMatch(s, @"\A[0-9]{1,6}(\.[0-9]{1,6}){1,4}\z")) return "不明";
            var parts = s.Split('.');
            // Fail closed for an IPv4-shaped string, even if an old version could look identical.
            if (parts.Length == 4 && parts.All(p => int.Parse(p, CultureInfo.InvariantCulture) <= 255)) return "不明";
            return s;
        }
        public static string Vendor(object value)
        {
            string s = (Convert.ToString(value, CultureInfo.InvariantCulture) ?? "").ToUpperInvariant();
            if (s.Contains("NVIDIA")) return "NVIDIA";
            if (s.Contains("ADVANCED MICRO DEVICES") || Regex.IsMatch(s, @"\b(AMD|ATI)\b")) return "AMD";
            if (s.Contains("INTEL")) return "Intel";
            if (s.Contains("QUALCOMM")) return "Qualcomm";
            if (s.Contains("MICROSOFT")) return "Microsoft";
            return "その他/不明";
        }
        public static string LocalLabel(object value)
        {
            string s = Convert.ToString(value, CultureInfo.InvariantCulture) ?? "不明";
            return new string(s.Where(c => !char.IsControl(c)).Take(120).ToArray());
        }
        public static bool IsLocalExe(string path)
        {
            return path != null && path.Length <= 260 && Regex.IsMatch(path, @"\A[A-Za-z]:\\") &&
                !path.Substring(3).Contains(":") && !path.Contains("\0") &&
                path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase);
        }
        public static string FileName(string path)
        {
            if (path == null) return "";
            string[] parts = path.Replace('/', '\\').Split('\\');
            return parts[parts.Length - 1];
        }
        private static string Canonical(string path)
        {
            return (path ?? "").Replace('/', '\\').Trim().Trim('"');
        }
        public static bool ValidWindow(DateTime start, DateTime end, DateTime now)
        {
            return start.Kind == DateTimeKind.Utc && end.Kind == DateTimeKind.Utc &&
                end > start && end - start <= TimeSpan.FromHours(MaxWindowHours) &&
                end <= now.AddSeconds(5) && start >= now.AddDays(-7);
        }
        public static ModuleKind ClassifyModule(string name)
        {
            // Only fixed classifications leave the parser, not arbitrary module names or paths.
            string n = FileName(name).ToLowerInvariant();
            if (new[] { "ntdll.dll", "kernelbase.dll", "kernel32.dll" }.Contains(n)) return ModuleKind.WindowsCore;
            if (new[] { "nvwgf2umx.dll", "nvwgf2um.dll", "nvldumdx.dll", "atidxx64.dll", "atidxx32.dll", "amdxx64.dll", "igd10iumd64.dll", "igd12umd64.dll", "dxgi.dll", "d3d11.dll", "d3d12.dll" }.Contains(n)) return ModuleKind.Graphics;
            if (new[] { "vcruntime140.dll", "vcruntime140_1.dll", "msvcp140.dll", "msvcr120.dll", "ucrtbase.dll" }.Contains(n)) return ModuleKind.VisualCpp;
            return string.IsNullOrEmpty(n) ? ModuleKind.Unknown : ModuleKind.Other;
        }
        public static ParseOutcome ParseEvent(string xml, string targetPath, DateTime start, DateTime end, out EventFact fact)
        {
            fact = null;
            if (string.IsNullOrEmpty(xml) || xml.Length > 65536) return ParseOutcome.Malformed;
            try
            {
                var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 65536 };
                XDocument doc;
                using (var sr = new StringReader(xml))
                using (var reader = XmlReader.Create(sr, settings)) doc = XDocument.Load(reader, LoadOptions.None);
                XNamespace ns = "http://schemas.microsoft.com/win/2004/08/events/event";
                if (doc.Root == null || doc.Root.Name != ns + "Event") return ParseOutcome.Unsupported;
                var system = doc.Root.Element(ns + "System");
                if (system == null) return ParseOutcome.Unsupported;
                int id;
                if (!int.TryParse((string)system.Element(ns + "EventID"), out id)) return ParseOutcome.Unsupported;
                string provider = (string)system.Element(ns + "Provider")?.Attribute("Name");
                string channel = (string)system.Element(ns + "Channel");
                DateTime timestamp;
                if (!DateTime.TryParse((string)system.Element(ns + "TimeCreated")?.Attribute("SystemTime"), CultureInfo.InvariantCulture,
                    DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out timestamp)) return ParseOutcome.Unsupported;
                if (timestamp < start || timestamp > end) return ParseOutcome.NotTarget;
                EventKind kind;
                if (id == 1000 && provider == "Application Error" && channel == "Application") kind = EventKind.ApplicationCrash;
                else if (id == 1002 && provider == "Application Hang" && channel == "Application") kind = EventKind.ApplicationHang;
                else if (id == 4101 && provider == "Display" && channel == "System") kind = EventKind.DisplayRecovery;
                else if (id == 41 && provider == "Microsoft-Windows-Kernel-Power" && channel == "System") kind = EventKind.UncleanRestart;
                else return ParseOutcome.Unsupported;
                var data = new Dictionary<string, string>(StringComparer.Ordinal);
                var eventData = doc.Root.Element(ns + "EventData");
                if (eventData != null)
                {
                    foreach (var element in eventData.Elements(ns + "Data").Take(64))
                    {
                        string key = (string)element.Attribute("Name");
                        if (key != null && new[] { "AppName", "AppPath", "ExeFileName", "ModuleName", "ModulePath", "AppVersion", "ModuleVersion", "FaultingOffset", "ExceptionCode" }.Contains(key))
                        {
                            if (data.ContainsKey(key)) return ParseOutcome.Unsupported;
                            data.Add(key, element.Value);
                        }
                    }
                }
                var result = new EventFact { Kind = kind, TimeUtc = timestamp, Match = MatchKind.SystemContext };
                if (kind == EventKind.ApplicationCrash || kind == EventKind.ApplicationHang)
                {
                    string appPath, appName;
                    data.TryGetValue("AppPath", out appPath);
                    if (string.IsNullOrWhiteSpace(appPath)) data.TryGetValue("ExeFileName", out appPath);
                    data.TryGetValue("AppName", out appName);
                    if (!string.IsNullOrWhiteSpace(appPath))
                    {
                        if (!string.Equals(Canonical(appPath), Canonical(targetPath), StringComparison.OrdinalIgnoreCase)) return ParseOutcome.NotTarget;
                        result.Match = MatchKind.ExactPath;
                    }
                    else
                    {
                        if (string.IsNullOrWhiteSpace(appName)) return ParseOutcome.Unsupported;
                        if (!string.Equals(FileName(appName), FileName(targetPath), StringComparison.OrdinalIgnoreCase)) return ParseOutcome.NotTarget;
                        result.Match = MatchKind.NameOnly;
                    }
                    string module, code;
                    data.TryGetValue("ModuleName", out module);
                    string modulePath, appVersion, moduleVersion, faultOffset;
                    data.TryGetValue("ModulePath", out modulePath); data.TryGetValue("AppVersion", out appVersion);
                    data.TryGetValue("ModuleVersion", out moduleVersion); data.TryGetValue("FaultingOffset", out faultOffset);
                    CrashDetails.Attach(result, targetPath, module, modulePath, appVersion, moduleVersion, faultOffset);
                    data.TryGetValue("ExceptionCode", out code);
                    result.ExceptionCode = CrashDetails.Exception(code);
                }
                fact = result;
                return ParseOutcome.Accepted;
            }
            catch (XmlException) { return ParseOutcome.Malformed; }
            catch (ArgumentException) { return ParseOutcome.Malformed; }
        }
        public static List<Finding> Analyze(Snapshot scan)
        {
            var list = new List<Finding>();
            var app = scan.Application.Events;
            int crash = app.Count(x => x.Kind == EventKind.ApplicationCrash);
            int hang = app.Count(x => x.Kind == EventKind.ApplicationHang);
            if (scan.System.Events.Any(x => x.Kind == EventKind.UncleanRestart)) list.Add(new Finding {
                Evidence = "同じ時間範囲に、PC全体の正常でない終了を示す Kernel-Power 41 の記録があります。",
                Candidate = "ゲーム以外を含むPC全体の問題を、まず切り分ける必要があります。",
                Unknown = "記録時刻は次回起動時です。電源・メモリ・ドライバーのどれが原因か、この記録だけでは分かりません。",
                StepId = "stop" });
            if (crash + hang > 0) list.Add(new Finding {
                Evidence = "選択対象とのパス完全一致 " + app.Count(x => x.Match == MatchKind.ExactPath) + " 件 / EXE名のみ一致 " + app.Count(x => x.Match == MatchKind.NameOnly) + " 件。内訳: クラッシュ " + crash + " 件 / 応答停止 " + hang + " 件。",
                Candidate = "アプリ・配布ファイル・実行環境などを順に確認する候補があります。",
                Unknown = app.Any(x => x.Match == MatchKind.NameOnly) ? "名前のみ一致の記録は別の実行ファイルの可能性が残ります。イベントだけでは根因を確定しません。" : "対象とのパス一致を確認していますが、障害モジュールや例外だけでは根因を確定しません。",
                StepId = "files" });
            if (app.Any(x => x.Module == ModuleKind.Graphics) || scan.System.Events.Any(x => x.Kind == EventKind.DisplayRecovery)) list.Add(new Finding {
                Evidence = "描画系に分類される障害モジュール、またはPC全体の Display 4101 の記録があります。",
                Candidate = "描画経路・ゲーム側の描画設定・ドライバー互換性を確認する手掛かりです。",
                Unknown = "GPU故障やドライバー不具合の証明ではありません。Display 4101 は別アプリの影響でも記録されます。",
                StepId = "graphics" });
            if (app.Any(x => x.Module == ModuleKind.VisualCpp)) list.Add(new Finding {
                Evidence = "実行環境に分類されるモジュールが障害記録に現れています。",
                Candidate = "ゲーム公式が指定する Visual C++ ランタイムの版と構成を確認できます。",
                Unknown = "モジュール名だけでDLL破損や不足とは判断できません。",
                StepId = "runtime" });
            if (scan.Hardware.Disks.Any(x => x.FreeMiB.HasValue && x.TotalMiB > 0 && (x.FreeMiB < 5120 || (double)x.FreeMiB.Value / x.TotalMiB.Value < .05))) list.Add(new Finding {
                Evidence = "取得時の空き容量が5 GiB未満、または容量の5%未満の対象ドライブがあります。",
                Candidate = "更新・一時ファイルの書き込み余裕を確認する候補です。これは本ツールの確認目安です。",
                Unknown = "ゲーム固有の必要容量や不具合発生時の空き容量は判定していません。",
                StepId = "space" });
            if (scan.Hardware.FreeMemoryMiB.HasValue && scan.Hardware.FreeMemoryMiB < 1024) list.Add(new Finding {
                Evidence = "取得時の利用可能な物理メモリが1 GiB未満でした（本ツールの確認目安）。",
                Candidate = "作業を保存し、不要なアプリを自分で閉じて、同条件と比較する候補です。",
                Unknown = "瞬間値であり、ゲーム実行中のメモリ不足やRAM故障の証明ではありません。",
                StepId = "memory" });
            if (crash + hang == 0) list.Add(new Finding {
                Evidence = "この取得結果には選択した実行ファイルに対応するクラッシュ・応答停止記録がありません。",
                Candidate = "対象EXE、発生時刻、ランチャー側の更新状態や公式要件を確認してください。",
                Unknown = "正常・解決を意味しません。ログがない失敗、別EXE、権限不足、上限到達、未対応形式などは判定できません。",
                StepId = "observe" });
            return list;
        }
        public static readonly GuideStep[] Steps = {
            new GuideStep { Id="observe", Title="発生場面と対象を確認", Instructions="ゲーム本体のEXEと発生時刻を選びます。ランチャーと本体が別の場合があります。Steam等の更新完了、ゲーム公式の障害・必要環境を確認します。", Warning="公式情報を確認するだけで、ファイルや設定は変更しません。", GuideUrl="https://gemnao.pages.dev/guide/pc-game-crash", OfficialUrl="https://help.steampowered.com/ja/faqs/view/21F5-8D5D-0141-7A5E" },
            new GuideStep { Id="files", Title="配布ファイルの検証手順を確認", Instructions="Steamならゲームを終了し、セーブとMOD構成を控えてから、ライブラリ → プロパティ → インストール済みファイル → 整合性確認。Steam以外はその配布元の公式手順を確認します。", Warning="実行は自分で行います。再取得でMODの上書きが元に戻ることがあります。セーブを削除しません。", GuideUrl="https://gemnao.pages.dev/guide/verify-steam-files", OfficialUrl="https://help.steampowered.com/ja/faqs/view/0C48-FCBD-DA71-93EB" },
            new GuideStep { Id="graphics", Title="描画環境とドライバー版を照合", Instructions="表示された版をデバイス マネージャーと照合し、PC/GPUメーカー公式とゲームの既知問題を確認します。最近の変更は手掛かりですが、版の日付を更新実施日とみなしません。", Warning="この初期版は更新・削除しません。DDU、オーバークロック、BIOS変更は案内対象外です。", GuideUrl="https://gemnao.pages.dev/guide/gpu-driver-update", OfficialUrl="https://support.microsoft.com/en-us/windows/hardware/display-graphics/troubleshooting-blank-screens-in-windows" },
            new GuideStep { Id="runtime", Title="必要ランタイムの公式要件を照合", Instructions="ゲーム公式が指定する年版とx86/x64を確認し、Microsoftの公式配布情報と照合します。", Warning="障害モジュールに現れただけで再インストールしません。DLL単体配布サイトは利用せず、既存の版を削除しません。", GuideUrl="https://gemnao.pages.dev/guide/visual-c-runtime-error", OfficialUrl="https://learn.microsoft.com/ja-jp/cpp/windows/latest-supported-vc-redist" },
            new GuideStep { Id="space", Title="対象ドライブの空き容量を確認", Instructions="Windowsの設定 → システム → ストレージで使用量を自分で確認し、ゲーム公式の必要容量と比べます。", Warning="自動クリーンアップは行いません。セーブ、不明なファイル、回復用データを削除しないでください。", GuideUrl="https://gemnao.pages.dev/guide/steam-disk-write-error", OfficialUrl="https://support.microsoft.com/en-us/windows/free-up-drive-space-in-windows-85529ccb-c365-490d-b548-831022bc9b32" },
            new GuideStep { Id="memory", Title="不要なアプリを閉じた条件で比較", Instructions="保存していない作業を保存し、不要なアプリを自分で終了します。安全に起動できる場合だけ、同じ場面・同じ長さで比較します。", Warning="サービス強制停止やページファイル変更は行いません。空きRAMはその瞬間の値です。", GuideUrl="https://gemnao.pages.dev/guide/pc-game-crash", OfficialUrl="https://support.microsoft.com/ja-jp/windows/experience/system-configuration-tools-in-windows" },
            new GuideStep { Id="stop", Title="PC全体の異常なら再現を中止", Instructions="PCの電源断・再起動・フリーズが続く場合、負荷テストをせず、作業を保存してPCメーカーや修理窓口へ相談してください。", Warning="焦げた臭い、異常な発熱などがあれば使用を中止してください。このツールではハードウェア故障を証明・修理できません。", GuideUrl="https://gemnao.pages.dev/guide/pc-game-crash", OfficialUrl="https://learn.microsoft.com/en-us/troubleshoot/windows-client/performance/event-id-41-restart" }
        };
        public static string StatusText(ReadStatus status)
        {
            switch (status) { case ReadStatus.Complete: return "取得完了（指定範囲のみ）"; case ReadStatus.AccessDenied: return "アクセス拒否・昇格しません"; case ReadStatus.Unavailable: return "利用できません"; case ReadStatus.TimedOut: return "時間上限・不完全"; case ReadStatus.Partial: return "一部のみ・不完全"; case ReadStatus.Cancelled: return "中止・不完全"; default: return "未取得"; }
        }
        public static string Compare(Snapshot before, Snapshot after, TrialOutcome result)
        {
            if (before == null || after == null) return "比較には取得前後の2回の結果が必要です。";
            if (before.Game != after.Game || before.Symptom != after.Symptom) return "比較できません: ゲーム区分または症状が異なります。";
            if (before.TargetSession == Guid.Empty || before.TargetSession != after.TargetSession) return "比較できません: 対象セッションが異なります。";
            if (before.AttemptId != Guid.Empty && before.AttemptId == after.AttemptId) return "比較しません: 同じ記録の読み直しです。新しい再テストではありません。";
            if (after.StartUtc <= before.EndUtc) return "比較できません: 観測範囲が重なっています。対処前の記録を再カウントするためです。";
            string outcome = new[] { "未確認", "改善した（本人の申告）", "変わらない（本人の申告）", "悪化した（本人の申告）", "判断できない（本人の申告）" }[(int)result];
            bool complete = before.Application.Status == ReadStatus.Complete && after.Application.Status == ReadStatus.Complete && !before.Application.LimitReached && !after.Application.LimitReached;
            double a = (before.EndUtc - before.StartUtc).TotalMinutes, b = (after.EndUtc - after.StartUtc).TotalMinutes;
            var text = new StringBuilder();
            text.AppendLine("本人の再テスト結果: " + outcome);
            text.AppendLine("対象: 同じセッションで選択したEXE / 観測範囲は非重複");
            text.AppendLine("選択アプリの記録件数: 前 " + before.Application.Events.Count + " 件（" + a.ToString("0.0", CultureInfo.InvariantCulture) + "分） → 後 " + after.Application.Events.Count + " 件（" + b.ToString("0.0", CultureInfo.InvariantCulture) + "分）");
            if (!complete) text.AppendLine("取得不足があるため件数の増減を評価できません。");
            if (Math.Abs(a - b) > .1) text.AppendLine("観測時間が異なります。件数だけを改善の根拠にできません。");
            text.AppendLine("ゲームを実際に同条件で試したかは自動検証していません。記録ゼロは解決の証明ではなく、変更の因果関係も確定しません。");
            return text.ToString();
        }
        public static string BuildReport(Snapshot current, Snapshot baseline, TrialOutcome outcome, IDictionary<string, StepState> states, bool includeActions = true, bool includeKnownModuleNames = false)
        {
            // Explicit, closed projection: never reflect/serialize collector objects or arbitrary strings.
            var b = new StringBuilder();
            b.AppendLine("ゲムなお Windows診断 試作 " + Version + " / 選別済みローカルレポート");
            b.AppendLine("完全な匿名化を保証しません。共有前に内容を確認してください。外部への送信機能はありません。");
            b.AppendLine("対象名・パス・ユーザー名・生ログ・端末IDは出力しません。CPU/GPU名はローカル画面のみです。");
            b.AppendLine("値は取得時の状態です。原因確定・正常判定・自動修復は行いません。\n");
            if (baseline != null && baseline != current) { AppendSnapshot(b, baseline, "対処前", includeKnownModuleNames); b.AppendLine(); }
            AppendSnapshot(b, current, baseline == null || baseline == current ? "現在" : "対処後", includeKnownModuleNames);
            if (baseline != null && baseline != current) { b.AppendLine("\n【前後比較】"); b.AppendLine(Compare(baseline, current, outcome)); }
            b.AppendLine(CrashDetails.PatternReport(current, baseline, includeKnownModuleNames));
            if (includeActions)
            {
            b.AppendLine("\n【手順の状態（本人による記録）】");
            foreach (var step in Steps)
            {
                StepState state;
                if (states == null || !states.TryGetValue(step.Id, out state)) state = StepState.NotStarted;
                b.AppendLine(step.Title + ": " + StateText(state));
            }
            b.AppendLine("\n【手動の次の一歩】");
            foreach (var id in Analyze(current).Select(x => x.StepId).Distinct())
            {
                var step = Steps.First(x => x.Id == id);
                b.AppendLine(step.Title + "\n" + step.Instructions + "\n注意: " + step.Warning + "\nガイド: " + step.GuideUrl + "\n公式: " + step.OfficialUrl + "\n");
            }
            }
            b.AppendLine("不明: 温度・電源容量/劣化・RAM健全性・GPU健全性・ゲーム固有の要件を満たすか・最近の更新実施日・セーブ/MOD状態。\n記録が残らない起動失敗、Windows Error Reporting 1001、他のランチャー/子EXEは対象外です。\nWilds固有コースでCrashReportの追加同意時のみ、ダンプの例外・モジュール等の限定項目を解析します。メモリ内容・レジスタ・スタック・命令・シンボル解析は対象外です。");
            return b.ToString();
        }
        public static string StateText(StepState state)
        {
            switch (state) { case StepState.Checked: return "内容を確認"; case StepState.Tried: return "自分で試した"; case StepState.Skipped: return "見送った"; default: return "実施の記録なし"; }
        }
        private static void AppendSnapshot(StringBuilder b, Snapshot s, string title, bool includeKnownModuleNames)
        {
            if (s == null) return;
            b.AppendLine("【" + title + "の取得事実】");
            b.AppendLine(CaptureWorkflow.Description(s));
            if (s.PriorRestartObserved) b.AppendLine("この診断内の先行取得でPC全体の終了記録あり。今回の件数には加算せず、再現中止の注意を保持しています。");
            b.AppendLine("観測幅: " + (s.EndUtc - s.StartUtc).TotalMinutes.ToString("0.0", CultureInfo.InvariantCulture) + "分 / 個々の時刻は観測終了からの相対値");
            var h = s.Hardware;
            b.AppendLine("OS内部版（10.0でもWindows 11の場合あり）: " + NumericVersion(h.OsVersion) + " / " + StatusText(h.OsStatus));
            b.AppendLine("CPUメーカー分類: " + Vendor(h.CpuVendor) + " / 論理プロセッサ: " + Number(h.LogicalProcessors) + " / " + StatusText(h.CpuStatus));
            b.AppendLine("物理RAM: " + Number(h.TotalMemoryMiB) + " MiB / 利用可能: " + Number(h.FreeMemoryMiB) + " MiB（取得時）");
            b.AppendLine("GPU: " + StatusText(h.GpuStatus));
            foreach (var gpu in h.Gpus.Take(8)) b.AppendLine("  メーカー分類: " + Vendor(gpu.Vendor) + " / ドライバー版: " + NumericVersion(gpu.DriverVersion));
            b.AppendLine("容量: " + StatusText(h.DiskStatus));
            foreach (var disk in h.Disks.Take(2)) b.AppendLine("  " + (disk.IsSystem ? "Windows側" : "選択ゲーム側") + ": 空き " + Number(disk.FreeMiB) + " / 全体 " + Number(disk.TotalMiB) + " MiB");
            AppendLog(b, s.Application, "Application", s.EndUtc, includeKnownModuleNames);
            AppendLog(b, s.System, "System（PC全体の参考記録）", s.EndUtc, includeKnownModuleNames);
            b.AppendLine("\n【観測 → 原因候補 → 不明】");
            foreach (var f in Analyze(s)) b.AppendLine("観測: " + f.Evidence + "\n候補: " + f.Candidate + "\n不明: " + f.Unknown + "\n");
        }
        private static string Number(long? n) { return n.HasValue && n >= 0 ? n.Value.ToString(CultureInfo.InvariantCulture) : "不明"; }
        private static void AppendLog(StringBuilder b, LogFacts log, string label, DateTime end, bool knownNames)
        {
            b.AppendLine(label + ": " + StatusText(log.Status) + " / 確認 " + log.Examined + " / 未対応・解析不能 " + log.Unsupported + " / 上限 " + (log.LimitReached ? "到達" : "未到達"));
            foreach (var e in log.Events.Take(MaxEventsPerLog))
            {
                string kind = e.Kind == EventKind.ApplicationCrash ? "Application Error 1000" : e.Kind == EventKind.ApplicationHang ? "Application Hang 1002" : e.Kind == EventKind.DisplayRecovery ? "Display 4101" : "Kernel-Power 41";
                string match = e.Match == MatchKind.ExactPath ? "パス完全一致（パス非表示）" : e.Match == MatchKind.NameOnly ? "EXE名のみ一致・別アプリの可能性あり" : "PC全体・対象ゲームとの関連は不明";
                string module = CrashDetails.ModuleText(e, knownNames);
                string code = Regex.IsMatch(e.ExceptionCode ?? "", @"\A[A-F0-9]{8}\z") ? e.ExceptionCode : "不明";
                b.AppendLine("  約" + Math.Max(0, (end - e.TimeUtc).TotalMinutes).ToString("0.0", CultureInfo.InvariantCulture) + "分前: " + kind + " / " + match + " / モジュール分類: " + module + " / 例外: " + code);
                if (e.Kind == EventKind.ApplicationCrash) b.AppendLine("    アプリ版 " + CrashDetails.VersionText(e.AppVersionParts) + " / モジュール版 " + CrashDetails.VersionText(e.ModuleVersionParts) + " / モジュール内位置 " + CrashDetails.OffsetText(e.FaultOffset));
            }
        }
    }
}
